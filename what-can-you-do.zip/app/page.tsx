"use client"

import { useState, useRef, useEffect } from "react"
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  BookOpen,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleDot,
  Clock,
  Copy,
  Download,
  ExternalLink,
  FileText,
  FlaskConical,
  Gauge,
  HelpCircle,
  Info,
  LayoutDashboard,
  LineChart,
  Lock,
  Minus,
  Percent,
  PieChart,
  Play,
  Plus,
  Scale,
  Search,
  Settings,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Target,
  Trash2,
  TrendingDown,
  TrendingUp,
  Wallet,
  XCircle,
  Zap,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  Legend,
  Area,
  AreaChart,
  ComposedChart,
  Line,
  RadialBarChart,
  RadialBar,
  ReferenceLine,
} from "recharts"

type Page =
  | "landing"
  | "mode-selection"
  | "offer-check"
  | "parsed-preview"
  | "assumptions"
  | "manual-input"
  | "scenario-preview"
  | "scenario-result"
  | "portfolio"
  | "knowledge-base"
  | "report"

type RiskLevel = "low" | "medium" | "high"

const mockTimelineData = [
  { month: "0", base: 1000000, stress: 1000000, real: 1000000, label: "Старт" },
  { month: "6", base: 1058000, stress: 1020000, real: 1035000, label: "6 мес" },
  { month: "12", base: 1118000, stress: 1010000, real: 1068000, label: "12 мес" },
  { month: "18", base: 1180000, stress: 995000, real: 1098000, label: "18 мес" },
  { month: "24", base: 1245000, stress: 980000, real: 1125000, label: "24 мес" },
]

const mockFactorImpact = [
  { factor: "Комиссии брокера", impact: -18500, percent: -1.85, color: "#f59e0b" },
  { factor: "Комиссия УК", impact: -12000, percent: -1.2, color: "#f59e0b" },
  { factor: "НДФЛ на доход", impact: -31850, percent: -3.19, color: "#f97316" },
  { factor: "Инфляция", impact: -120000, percent: -12.0, color: "#ef4444" },
]

const mockMonthlyFlow = [
  { month: "Янв", income: 8500, expense: -2100 },
  { month: "Фев", income: 8500, expense: -2100 },
  { month: "Мар", income: 8500, expense: -2100 },
  { month: "Апр", income: 8500, expense: -2100 },
  { month: "Май", income: 8500, expense: -2100 },
  { month: "Июн", income: 8500, expense: -2100 },
]

const mockPortfolioData = [
  { name: "Облигации ОФЗ", value: 40, color: "#22d3ee" },
  { name: "Акции РФ", value: 25, color: "#34d399" },
  { name: "ETF", value: 20, color: "#fbbf24" },
  { name: "Денежный рынок", value: 15, color: "#a78bfa" },
]

const mockPortfolioTable = [
  { instrument: "ОФЗ 26238", type: "Облигации", amount: 400000, share: 40, ytd: 8.2, risk: "low" as RiskLevel },
  { instrument: "Сбербанк", type: "Акции", amount: 125000, share: 12.5, ytd: 15.4, risk: "medium" as RiskLevel },
  { instrument: "Газпром", type: "Акции", amount: 125000, share: 12.5, ytd: -8.2, risk: "high" as RiskLevel },
  { instrument: "FXUS", type: "ETF", amount: 200000, share: 20, ytd: 12.1, risk: "medium" as RiskLevel },
  { instrument: "LQDT", type: "Денежный рынок", amount: 150000, share: 15, ytd: 7.8, risk: "low" as RiskLevel },
]

const riskFlags = [
  { text: "Блокировка капитала на 3 года", level: "high" as RiskLevel, icon: Lock },
  { text: "Штраф 2% при досрочном выходе", level: "medium" as RiskLevel, icon: Percent },
  { text: "Доходность зависит от базового актива", level: "medium" as RiskLevel, icon: Activity },
  { text: "Нет гарантии возврата капитала", level: "high" as RiskLevel, icon: ShieldAlert },
]

function RiskBadge({ level, size = "default" }: { level: RiskLevel; size?: "sm" | "default" | "lg" }) {
  const config = {
    low: { 
      label: "Низкий", 
      className: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
      dot: "bg-emerald-400"
    },
    medium: { 
      label: "Средний", 
      className: "bg-amber-500/10 text-amber-400 border-amber-500/20",
      dot: "bg-amber-400"
    },
    high: { 
      label: "Высокий", 
      className: "bg-red-500/10 text-red-400 border-red-500/20",
      dot: "bg-red-400"
    },
  }
  const { label, className, dot } = config[level]
  const sizeClasses = {
    sm: "text-[10px] px-2 py-0.5 gap-1",
    default: "text-xs px-2.5 py-1 gap-1.5",
    lg: "text-sm px-3 py-1.5 gap-2",
  }
  return (
    <span className={`inline-flex items-center rounded-full border font-medium ${className} ${sizeClasses[size]}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${dot}`} />
      {label}
    </span>
  )
}

function MetricCard({
  title,
  value,
  subtitle,
  trend,
  trendValue,
  icon: Icon,
  variant = "neutral",
  size = "default",
}: {
  title: string
  value: string
  subtitle?: string
  trend?: "up" | "down" | "neutral"
  trendValue?: string
  icon?: React.ComponentType<{ className?: string }>
  variant?: "positive" | "negative" | "neutral" | "warning"
  size?: "default" | "large" | "hero"
}) {
  const variantClasses = {
    positive: "metric-positive",
    negative: "metric-negative",
    neutral: "metric-neutral",
    warning: "metric-card border-amber-500/20",
  }
  const sizeClasses = {
    default: "p-5",
    large: "p-6",
    hero: "p-8",
  }
  const valueClasses = {
    default: "text-2xl",
    large: "text-3xl",
    hero: "text-4xl lg:text-5xl",
  }
  return (
    <div className={`metric-card rounded-xl ${variantClasses[variant]} ${sizeClasses[size]}`}>
      <div className="flex items-start justify-between gap-4">
        <div className="space-y-2 flex-1 min-w-0">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{title}</p>
          <p className={`font-semibold tracking-tight stat-value ${valueClasses[size]}`}>{value}</p>
          {(subtitle || trendValue) && (
            <div className="flex items-center gap-2 flex-wrap">
              {trend && trendValue && (
                <span className={`inline-flex items-center gap-1 text-sm font-medium ${
                  trend === "up" ? "text-emerald-400" : trend === "down" ? "text-red-400" : "text-muted-foreground"
                }`}>
                  {trend === "up" && <TrendingUp className="h-3.5 w-3.5" />}
                  {trend === "down" && <TrendingDown className="h-3.5 w-3.5" />}
                  {trendValue}
                </span>
              )}
              {subtitle && <span className="text-sm text-muted-foreground">{subtitle}</span>}
            </div>
          )}
        </div>
        {Icon && (
          <div className={`shrink-0 p-3 rounded-xl ${
            variant === "positive" ? "bg-emerald-500/15" : 
            variant === "negative" ? "bg-red-500/15" : 
            variant === "warning" ? "bg-amber-500/15" :
            "bg-primary/10"
          }`}>
            <Icon className={`h-5 w-5 ${
              variant === "positive" ? "text-emerald-400" : 
              variant === "negative" ? "text-red-400" : 
              variant === "warning" ? "text-amber-400" :
              "text-primary"
            }`} />
          </div>
        )}
      </div>
    </div>
  )
}

function Stepper({ steps, currentStep }: { steps: string[]; currentStep: number }) {
  return (
    <div className="flex items-center justify-center gap-2 mb-12">
      {steps.map((step, index) => (
        <div key={step} className="flex items-center gap-2">
          <div className={`flex items-center gap-2.5 px-4 py-2.5 rounded-full text-sm font-medium transition-all ${
            index < currentStep
              ? "bg-primary/15 text-primary"
              : index === currentStep
                ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25"
                : "bg-muted/40 text-muted-foreground"
          }`}>
            {index < currentStep ? (
              <CheckCircle2 className="h-4 w-4" />
            ) : (
              <span className={`w-5 h-5 flex items-center justify-center text-xs rounded-full ${
                index === currentStep ? "bg-primary-foreground/20" : "bg-muted"
              }`}>
                {index + 1}
              </span>
            )}
            <span className="hidden sm:inline">{step}</span>
          </div>
          {index < steps.length - 1 && (
            <div className={`w-8 lg:w-12 h-px ${index < currentStep ? "bg-primary/40" : "bg-muted/40"}`} />
          )}
        </div>
      ))}
    </div>
  )
}

function DisclaimerBanner({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return (
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Info className="h-3.5 w-3.5 shrink-0" />
        <span>Это не инвестиционная рекомендация</span>
      </div>
    )
  }
  return (
    <div className="flex gap-3 items-start p-4 rounded-xl bg-muted/30 border border-border/50">
      <Info className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
      <p className="text-xs text-muted-foreground leading-relaxed">
        Сервис предоставляет информационный анализ. Не является инвестиционной рекомендацией.
      </p>
    </div>
  )
}

function TopNav({ currentPage, onNavigate }: { currentPage: Page; onNavigate: (page: Page) => void }) {
  const navItems = [
    { id: "offer-check" as Page, label: "Проверить" },
    { id: "manual-input" as Page, label: "Сценарий" },
    { id: "portfolio" as Page, label: "Портфель" },
    { id: "knowledge-base" as Page, label: "База знаний" },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-xl">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-8">
            <button 
              onClick={() => onNavigate("landing")} 
              className="flex items-center gap-2.5 group"
            >
              <div className="relative p-2 rounded-lg bg-gradient-to-br from-primary/20 to-primary/5 border border-primary/20 group-hover:border-primary/40 transition-colors">
                <FlaskConical className="h-4 w-4 text-primary" />
              </div>
              <span className="font-semibold text-base hidden sm:block">Scenario Lab</span>
            </button>
            
            <nav className="hidden lg:flex items-center">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`px-4 py-2 text-sm font-medium rounded-lg transition-all ${
                    currentPage === item.id
                      ? "bg-muted text-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>
          </div>
          
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="hidden sm:flex bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-[10px] font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5 animate-pulse" />
              Бесплатно
            </Badge>
            <Button 
              onClick={() => onNavigate("mode-selection")} 
              size="sm" 
              className="btn-glow text-primary-foreground font-medium h-9"
            >
              Начать анализ
              <ArrowRight className="ml-1.5 h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}

function HeroDashboardPreview() {
  const miniData = [
    { m: "0", v: 100, s: 100 },
    { m: "1", v: 103, s: 101 },
    { m: "2", v: 107, s: 99 },
    { m: "3", v: 105, s: 97 },
    { m: "4", v: 112, s: 96 },
    { m: "5", v: 118, s: 95 },
    { m: "6", v: 124, s: 98 },
  ]

  return (
    <div className="relative animate-float">
      <div className="absolute -inset-8 bg-primary/8 rounded-3xl blur-3xl" />
      <div className="absolute -inset-4 bg-gradient-to-br from-primary/10 to-transparent rounded-3xl blur-2xl" />
      
      <div className="relative glass-card rounded-2xl overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
        
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse-glow" />
              <span className="text-xs font-medium text-muted-foreground">Анализ завершён</span>
            </div>
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 text-[10px]">
              24 мес
            </Badge>
          </div>
          
          {/* Metrics */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 rounded-xl bg-emerald-500/8 border border-emerald-500/15">
              <p className="text-[10px] text-emerald-400/70 font-medium uppercase tracking-wider mb-1">Базовый</p>
              <p className="text-2xl font-bold text-emerald-400 stat-value">+24.5%</p>
              <p className="text-xs text-muted-foreground mt-1">1 245 000 ₽</p>
            </div>
            <div className="p-4 rounded-xl bg-red-500/8 border border-red-500/15">
              <p className="text-[10px] text-red-400/70 font-medium uppercase tracking-wider mb-1">Стресс</p>
              <p className="text-2xl font-bold text-red-400 stat-value">-2.0%</p>
              <p className="text-xs text-muted-foreground mt-1">980 000 ₽</p>
            </div>
          </div>

          {/* Chart */}
          <div className="h-24">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={miniData}>
                <defs>
                  <linearGradient id="heroGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#22d3ee" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#22d3ee" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <Area type="monotone" dataKey="v" stroke="#22d3ee" fill="url(#heroGrad)" strokeWidth={2} />
                <Area type="monotone" dataKey="s" stroke="#ef4444" fill="none" strokeWidth={1.5} strokeDasharray="4 4" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Risk Indicators */}
          <div className="flex items-center justify-between pt-3 border-t border-border/30">
            <div className="flex items-center gap-4">
              <RiskBadge level="medium" size="sm" />
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" />
                <span>Ликв. 65%</span>
              </div>
            </div>
          </div>

          {/* Flags */}
          <div className="flex gap-2 flex-wrap">
            <Badge variant="outline" className="bg-red-500/8 text-red-400 border-red-500/15 text-[10px]">
              <Lock className="h-2.5 w-2.5 mr-1" />
              Блок. 3г
            </Badge>
            <Badge variant="outline" className="bg-amber-500/8 text-amber-400 border-amber-500/15 text-[10px]">
              <Percent className="h-2.5 w-2.5 mr-1" />
              Штраф 2%
            </Badge>
          </div>
        </div>
      </div>
    </div>
  )
}

function FeatureCard({ 
  icon: Icon, 
  title, 
  description,
  onClick 
}: { 
  icon: React.ComponentType<{ className?: string }>
  title: string
  description: string
  onClick?: () => void
}) {
  const ref = useRef<HTMLButtonElement>(null)

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!ref.current) return
    const rect = ref.current.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100
    ref.current.style.setProperty('--mouse-x', `${x}%`)
    ref.current.style.setProperty('--mouse-y', `${y}%`)
  }

  return (
    <button
      ref={ref}
      onClick={onClick}
      onMouseMove={handleMouseMove}
      className="feature-card text-left p-6 rounded-xl w-full"
    >
      <div className="relative z-10">
        <div className="p-3 rounded-xl bg-primary/10 w-fit mb-4">
          <Icon className="h-5 w-5 text-primary" />
        </div>
        <h3 className="font-semibold mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
      </div>
    </button>
  )
}

function LandingPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const features = [
    {
      icon: Search,
      title: "Проверка предложения",
      desc: "Разбор условий, выявление комиссий и скрытых рисков",
    },
    {
      icon: Scale,
      title: "Сравнение сценариев",
      desc: "Базовый, стресс и реальная доходность в одном месте",
    },
    {
      icon: ShieldAlert,
      title: "Стресс-тестирование",
      desc: "Моделирование падения рынка и влияния на результат",
    },
    {
      icon: FileText,
      title: "Структурированный отчёт",
      desc: "Документ со всеми расчётами и допущениями",
    },
  ]

  const stats = [
    { value: "5 мин", label: "Среднее время анализа" },
    { value: "12+", label: "Параметров проверки" },
    { value: "3", label: "Сценария расчёта" },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative py-20 lg:py-32 hero-glow overflow-hidden">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 relative">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20">
                  <Sparkles className="h-3.5 w-3.5 text-primary" />
                  <span className="text-xs font-medium text-primary">Сценарный анализ инвестиций</span>
                </div>
                
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.1] tracking-tight">
                  Проверьте сценарий
                  <br />
                  <span className="text-primary">до вложения</span>
                </h1>
                
                <p className="text-lg text-muted-foreground max-w-md leading-relaxed">
                  Разберите условия, комиссии, налоги и риски. Без рекомендаций и продажи продуктов.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  onClick={() => onNavigate("offer-check")} 
                  className="btn-glow text-primary-foreground font-medium h-12 px-6"
                >
                  Проверить предложение
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  onClick={() => onNavigate("manual-input")} 
                  className="h-12 px-6 border-border/50 hover:bg-muted/50 font-medium"
                >
                  Собрать сценарий
                </Button>
              </div>

              <div className="flex items-center gap-6 pt-2">
                {[
                  { icon: CheckCircle2, text: "Бесплатно" },
                  { icon: CheckCircle2, text: "Без регистрации" },
                ].map((item) => (
                  <div key={item.text} className="flex items-center gap-2">
                    <item.icon className="h-4 w-4 text-emerald-400" />
                    <span className="text-sm text-muted-foreground">{item.text}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="hidden lg:block">
              <HeroDashboardPreview />
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 border-y border-border/30">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6">
          <div className="grid grid-cols-3 gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <p className="text-3xl lg:text-4xl font-bold text-primary stat-value">{stat.value}</p>
                <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold mb-3">Возможности</h2>
            <p className="text-muted-foreground max-w-lg mx-auto">
              Инструменты для анализа инвестиционных предложений
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {features.map((feature) => (
              <FeatureCard
                key={feature.title}
                icon={feature.icon}
                title={feature.title}
                description={feature.desc}
              />
            ))}
          </div>
        </div>
      </section>

      {/* What we do / don't do */}
      <section className="py-20 border-t border-border/30">
        <div className="container mx-auto max-w-5xl px-4 sm:px-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="p-6 rounded-2xl bg-emerald-500/5 border border-emerald-500/20">
              <div className="flex items-center gap-2.5 mb-6">
                <div className="p-2 rounded-lg bg-emerald-500/15">
                  <Check className="h-4 w-4 text-emerald-400" />
                </div>
                <h3 className="font-semibold text-emerald-400">Что делает сервис</h3>
              </div>
              <ul className="space-y-3">
                {["Разбирает условия предложения", "Рассчитывает сценарии", "Показывает скрытые риски", "Фиксирует все допущения"].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="p-6 rounded-2xl bg-red-500/5 border border-red-500/20">
              <div className="flex items-center gap-2.5 mb-6">
                <div className="p-2 rounded-lg bg-red-500/15">
                  <XCircle className="h-4 w-4 text-red-400" />
                </div>
                <h3 className="font-semibold text-red-400">Чего не делает</h3>
              </div>
              <ul className="space-y-3">
                {["Не рекомендует покупку", "Не продаёт продукты", "Не подключается к брокеру", "Не гарантирует доходность"].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-sm">
                    <XCircle className="h-4 w-4 text-red-400 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 border-t border-border/30">
        <div className="container mx-auto max-w-3xl px-4 sm:px-6 text-center">
          <h2 className="text-2xl sm:text-3xl font-bold mb-4">Готовы проверить сценарий?</h2>
          <p className="text-muted-foreground mb-8 max-w-md mx-auto">
            Выберите способ анализа и получите результат за несколько минут
          </p>
          <Button 
            size="lg" 
            onClick={() => onNavigate("mode-selection")} 
            className="btn-glow text-primary-foreground font-medium h-12 px-8"
          >
            Начать анализ
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </section>
    </div>
  )
}

function ModeSelectionPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const modes = [
    {
      id: "offer-check" as Page,
      icon: Search,
      title: "Проверить предложение",
      desc: "Вставьте текст — сервис выделит условия и риски",
      badge: "Популярный",
      gradient: "from-primary/20 to-primary/5",
    },
    {
      id: "manual-input" as Page,
      icon: LayoutDashboard,
      title: "Собрать сценарий",
      desc: "Введите параметры вручную для расчёта",
      badge: null,
      gradient: "from-emerald-500/15 to-emerald-500/5",
    },
    {
      id: "portfolio" as Page,
      icon: PieChart,
      title: "Проверить портфель",
      desc: "Оцените концентрацию и риск портфеля",
      badge: null,
      gradient: "from-amber-500/15 to-amber-500/5",
    },
    {
      id: "knowledge-base" as Page,
      icon: BookOpen,
      title: "База знаний",
      desc: "Справочник по финансовым инструментам",
      badge: null,
      gradient: "from-violet-500/15 to-violet-500/5",
    },
  ]

  return (
    <div className="container mx-auto max-w-4xl px-4 sm:px-6 py-16 lg:py-24">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold mb-3">Выберите режим</h1>
        <p className="text-muted-foreground">Как вы хотите проверить финансовый сценарий?</p>
      </div>
      
      <div className="grid sm:grid-cols-2 gap-4">
        {modes.map((mode) => (
          <button
            key={mode.id}
            onClick={() => onNavigate(mode.id)}
            className="feature-card text-left p-6 rounded-xl group"
          >
            <div className="relative z-10">
              <div className="flex items-start justify-between mb-5">
                <div className={`p-3 rounded-xl bg-gradient-to-br ${mode.gradient}`}>
                  <mode.icon className="h-5 w-5 text-foreground" />
                </div>
                {mode.badge && (
                  <Badge className="bg-primary/15 text-primary border-0 text-[10px]">{mode.badge}</Badge>
                )}
              </div>
              <h3 className="font-semibold mb-2">{mode.title}</h3>
              <p className="text-sm text-muted-foreground mb-4">{mode.desc}</p>
              <div className="flex items-center text-sm text-primary font-medium">
                Выбрать
                <ArrowRight className="h-4 w-4 ml-1.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}

function OfferCheckPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const [source, setSource] = useState("")
  const [offerText, setOfferText] = useState("")

  const checks = [
    "Заявленная доходность",
    "Скрытые комиссии",
    "Налоговые последствия",
    "Условия ликвидности",
    "Стресс-сценарий",
    "Риск-флаги"
  ]

  return (
    <div className="container mx-auto max-w-5xl px-4 sm:px-6 py-12">
      <div className="mb-10">
        <h1 className="text-2xl font-bold mb-2">Проверить предложение</h1>
        <p className="text-muted-foreground">Вставьте текст для анализа условий и рисков</p>
      </div>
      
      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card className="glass-card border-border/40">
            <CardContent className="p-6 space-y-6">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Источник предложения</Label>
                <Select value={source} onValueChange={setSource}>
                  <SelectTrigger className="bg-input/50 border-border/50 h-11">
                    <SelectValue placeholder="Выберите источник" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bank">Банк</SelectItem>
                    <SelectItem value="broker">Брокер</SelectItem>
                    <SelectItem value="uk">Управляющая компания</SelectItem>
                    <SelectItem value="advisor">Финансовый советник</SelectItem>
                    <SelectItem value="other">Другое</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label className="text-sm font-medium">Текст предложения</Label>
                <Textarea
                  value={offerText}
                  onChange={(e) => setOfferText(e.target.value)}
                  placeholder="Вставьте сюда текст инвестиционного предложения, которое хотите проанализировать..."
                  className="min-h-[200px] bg-input/50 border-border/50 resize-none text-sm"
                />
              </div>
              
              <Button
                className="w-full btn-glow text-primary-foreground font-medium h-12"
                onClick={() => onNavigate("parsed-preview")}
                disabled={!offerText}
              >
                Разобрать предложение
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <div className="p-5 rounded-xl glass-card border-border/40">
            <h3 className="font-medium mb-4 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-primary" />
              Что будет проверено
            </h3>
            <ul className="space-y-2.5">
              {checks.map((item) => (
                <li key={item} className="flex items-center gap-2.5 text-sm text-muted-foreground">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary/60" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <DisclaimerBanner />
        </div>
      </div>
    </div>
  )
}

function ParsedPreviewPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const parsedFields = [
    { label: "Сумма инвестиций", value: "1 000 000 ₽", status: "found" },
    { label: "Срок", value: "24 месяца", status: "found" },
    { label: "Заявленная доходность", value: "12% годовых", status: "found" },
    { label: "Комиссия за управление", value: "1.5% в год", status: "found" },
    { label: "Комиссия за результат", value: "20% от прибыли", status: "found" },
    { label: "Налогообложение", value: "НДФЛ 13%", status: "assumed" },
    { label: "Условия выхода", value: "Штраф 2% первые 12 мес", status: "found" },
  ]

  return (
    <div className="container mx-auto max-w-5xl px-4 sm:px-6 py-12">
      <Stepper steps={["Предложение", "Условия", "Допущения", "Расчёт"]} currentStep={1} />
      
      <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 mb-8 flex items-center gap-3">
        <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
        <div>
          <p className="text-sm font-medium text-emerald-400">Предложение разобрано</p>
          <p className="text-xs text-muted-foreground mt-0.5">Проверьте найденные условия и риск-флаги</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-5 gap-6 mb-8">
        <Card className="lg:col-span-3 glass-card border-border/40">
          <CardHeader className="pb-4">
            <CardTitle className="text-base flex items-center gap-2">
              <FileText className="h-4 w-4 text-primary" />
              Найденные параметры
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-0">
              {parsedFields.map((field) => (
                <div key={field.label} className="flex items-center justify-between py-3.5 border-b border-border/30 last:border-0">
                  <span className="text-sm text-muted-foreground">{field.label}</span>
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">{field.value}</span>
                    {field.status === "assumed" && (
                      <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/20 text-[10px]">
                        Допущение
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="lg:col-span-2 space-y-4">
          <div className="p-5 rounded-xl bg-amber-500/5 border border-amber-500/20">
            <div className="flex items-center gap-2 mb-4">
              <HelpCircle className="h-4 w-4 text-amber-400" />
              <h3 className="font-medium text-sm">Требует уточнения</h3>
            </div>
            <div className="space-y-2">
              <div className="p-3 rounded-lg bg-amber-500/10">
                <p className="text-sm font-medium">Комиссия за конвертацию</p>
                <p className="text-xs text-muted-foreground mt-0.5">Не указана в предложении</p>
              </div>
            </div>
          </div>

          <div className="p-5 rounded-xl bg-red-500/5 border border-red-500/20">
            <div className="flex items-center gap-2 mb-4">
              <AlertTriangle className="h-4 w-4 text-red-400" />
              <h3 className="font-medium text-sm">Риск-флаги</h3>
              <Badge className="bg-red-500/20 text-red-400 border-0 text-[10px] ml-auto">
                {riskFlags.length}
              </Badge>
            </div>
            <div className="space-y-2.5">
              {riskFlags.slice(0, 3).map((flag) => (
                <div key={flag.text} className="flex items-start gap-2.5">
                  <flag.icon className="h-3.5 w-3.5 text-muted-foreground shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs leading-snug">{flag.text}</p>
                  </div>
                  <RiskBadge level={flag.level} size="sm" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-between">
        <Button variant="outline" onClick={() => onNavigate("offer-check")} className="border-border/50">
          Назад
        </Button>
        <Button className="btn-glow text-primary-foreground font-medium" onClick={() => onNavigate("assumptions")}>
          Подтвердить условия
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

function AssumptionsPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const [confirmed, setConfirmed] = useState(false)

  const assumptions = [
    { field: "Комиссия за конвертацию", explanation: "Комиссия при покупке/продаже валютных активов", defaultValue: "0.3%", editable: true },
    { field: "Налог на купоны/дивиденды", explanation: "НДФЛ на текущий доход", defaultValue: "13%", editable: false },
    { field: "Реинвестирование дохода", explanation: "Автоматическое реинвестирование", defaultValue: "Да", editable: true },
  ]

  return (
    <div className="container mx-auto max-w-4xl px-4 sm:px-6 py-12">
      <Stepper steps={["Предложение", "Условия", "Допущения", "Расчёт"]} currentStep={2} />

      <div className="mb-10">
        <h1 className="text-2xl font-bold mb-2">Подтвердите допущения</h1>
        <p className="text-muted-foreground">Укажите значения для параметров, которые не указаны в предложении</p>
      </div>

      <div className="space-y-3 mb-8">
        {assumptions.map((item) => (
          <Card key={item.field} className="glass-card border-border/40">
            <CardContent className="p-5">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-medium text-sm">{item.field}</h3>
                    {item.editable && (
                      <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/20 text-[10px]">
                        Можно изменить
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{item.explanation}</p>
                </div>
                <Input 
                  defaultValue={item.defaultValue} 
                  disabled={!item.editable}
                  className="w-24 bg-input/50 border-border/50 text-sm h-9 text-right" 
                />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="p-4 rounded-xl bg-muted/30 border border-border/50 mb-8">
        <label className="flex items-start gap-3 cursor-pointer">
          <Checkbox 
            id="confirm" 
            checked={confirmed} 
            onCheckedChange={(checked) => setConfirmed(checked === true)} 
            className="mt-0.5"
          />
          <span className="text-sm text-muted-foreground leading-relaxed">
            Я понимаю, что расчёт будет основан на введённых данных и допущениях. 
            Результат носит информационный характер.
          </span>
        </label>
      </div>

      <div className="flex justify-between">
        <Button variant="outline" onClick={() => onNavigate("parsed-preview")} className="border-border/50">
          Назад
        </Button>
        <Button
          className="btn-glow text-primary-foreground font-medium"
          disabled={!confirmed}
          onClick={() => onNavigate("scenario-preview")}
        >
          Продолжить
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

function ManualInputPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const [includeTaxes, setIncludeTaxes] = useState(true)
  const [includeInflation, setIncludeInflation] = useState(true)

  return (
    <div className="container mx-auto max-w-5xl px-4 sm:px-6 py-12 pb-32">
      <div className="mb-10">
        <h1 className="text-2xl font-bold mb-2">Собрать сценарий</h1>
        <p className="text-muted-foreground">Введите параметры для моделирования инвестиционного сценария</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card className="glass-card border-border/40">
            <CardContent className="p-6 space-y-6">
              <div className="grid sm:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Сумма инвестиций</Label>
                  <div className="relative">
                    <Input type="number" defaultValue="1000000" className="bg-input/50 border-border/50 pr-8" />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">₽</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Срок инвестирования</Label>
                  <div className="relative">
                    <Input type="number" defaultValue="24" className="bg-input/50 border-border/50 pr-12" />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">мес</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Ожидаемая доходность</Label>
                  <div className="relative">
                    <Input type="number" defaultValue="12" className="bg-input/50 border-border/50 pr-12" />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">% год</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Комиссии</Label>
                  <div className="relative">
                    <Input type="number" defaultValue="1.5" className="bg-input/50 border-border/50 pr-12" />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">% год</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Ставка налога</Label>
                  <div className="relative">
                    <Input type="number" defaultValue="13" className="bg-input/50 border-border/50 pr-8" />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">%</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Ожидаемая инфляция</Label>
                  <div className="relative">
                    <Input type="number" defaultValue="8" className="bg-input/50 border-border/50 pr-12" />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">% год</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Стресс-падение</Label>
                  <div className="relative">
                    <Input type="number" defaultValue="20" className="bg-input/50 border-border/50 pr-8" />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">%</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Вероятность досрочного выхода</Label>
                  <Select defaultValue="low">
                    <SelectTrigger className="bg-input/50 border-border/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Маловероятен</SelectItem>
                      <SelectItem value="medium">Возможен</SelectItem>
                      <SelectItem value="high">Вероятен</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator className="bg-border/30" />

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-sm font-medium">Учитывать налоги</Label>
                    <p className="text-xs text-muted-foreground mt-0.5">НДФЛ на доходы</p>
                  </div>
                  <Switch checked={includeTaxes} onCheckedChange={setIncludeTaxes} />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-sm font-medium">Учитывать инфляцию</Label>
                    <p className="text-xs text-muted-foreground mt-0.5">Реальная доходность</p>
                  </div>
                  <Switch checked={includeInflation} onCheckedChange={setIncludeInflation} />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card className="glass-card border-border/40 sticky top-24">
            <CardHeader className="pb-4">
              <CardTitle className="text-base flex items-center gap-2">
                <Gauge className="h-4 w-4 text-primary" />
                Предварительная оценка
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-xl bg-emerald-500/8 border border-emerald-500/15">
                  <p className="text-[10px] text-emerald-400/70 font-medium uppercase tracking-wider mb-1">Базовый</p>
                  <p className="text-xl font-bold text-emerald-400 stat-value">+24.5%</p>
                  <p className="text-xs text-muted-foreground mt-1">1 245 000 ₽</p>
                </div>
                <div className="p-4 rounded-xl bg-red-500/8 border border-red-500/15">
                  <p className="text-[10px] text-red-400/70 font-medium uppercase tracking-wider mb-1">Стресс</p>
                  <p className="text-xl font-bold text-red-400 stat-value">-2.0%</p>
                  <p className="text-xs text-muted-foreground mt-1">980 000 ₽</p>
                </div>
              </div>
              
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Риск сценария</span>
                  <RiskBadge level="medium" size="sm" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Ликвидность</span>
                  <RiskBadge level="medium" size="sm" />
                </div>
              </div>

              <div className="pt-3 border-t border-border/30">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Разброс сценариев</span>
                  <span className="font-medium text-amber-400">265 000 ₽</span>
                </div>
                <div className="risk-indicator" style={{ "--risk-level": "65%" } as React.CSSProperties} />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-background/95 backdrop-blur-xl border-t border-border/40">
        <div className="container mx-auto max-w-5xl flex justify-between">
          <Button variant="outline" onClick={() => onNavigate("mode-selection")} className="border-border/50">
            Назад
          </Button>
          <Button className="btn-glow text-primary-foreground font-medium" onClick={() => onNavigate("scenario-preview")}>
            Предпросмотр сценария
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}

function ScenarioPreviewPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const [confirmed, setConfirmed] = useState(false)

  const params = [
    { label: "Сумма инвестиций", value: "1 000 000 ₽" },
    { label: "Срок", value: "24 месяца" },
    { label: "Ожидаемая доходность", value: "12% годовых" },
    { label: "Комиссии", value: "1.5% годовых" },
    { label: "Налог НДФЛ", value: "13%" },
    { label: "Инфляция", value: "8% годовых" },
    { label: "Стресс-падение", value: "20%" },
  ]

  return (
    <div className="container mx-auto max-w-4xl px-4 sm:px-6 py-12">
      <Stepper steps={["Предложение", "Условия", "Допущения", "Расчёт"]} currentStep={3} />

      <div className="mb-10">
        <h1 className="text-2xl font-bold mb-2">Проверьте параметры</h1>
        <p className="text-muted-foreground">Убедитесь, что всё указано корректно перед запуском расчёта</p>
      </div>

      <Card className="glass-card border-border/40 mb-6">
        <CardContent className="p-6">
          <div className="grid sm:grid-cols-2 gap-x-8 gap-y-1">
            {params.map((param) => (
              <div key={param.label} className="flex items-center justify-between py-3 border-b border-border/30">
                <span className="text-sm text-muted-foreground">{param.label}</span>
                <span className="font-medium text-sm">{param.value}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="p-4 rounded-xl bg-amber-500/8 border border-amber-500/20 mb-6">
        <div className="flex gap-3">
          <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
          <p className="text-sm text-amber-200/80 leading-relaxed">
            Результат расчёта зависит от точности введённых данных. При неточных параметрах 
            фактический результат может существенно отличаться.
          </p>
        </div>
      </div>

      <div className="p-4 rounded-xl bg-muted/30 border border-border/50 mb-8">
        <label className="flex items-start gap-3 cursor-pointer">
          <Checkbox 
            id="confirm-calc" 
            checked={confirmed} 
            onCheckedChange={(checked) => setConfirmed(checked === true)} 
            className="mt-0.5"
          />
          <span className="text-sm text-muted-foreground leading-relaxed">
            Подтверждаю параметры расчёта. Понимаю, что результат носит информационный характер 
            и не является инвестиционной рекомендацией.
          </span>
        </label>
      </div>

      <div className="flex justify-between">
        <Button variant="outline" onClick={() => onNavigate("assumptions")} className="border-border/50">
          Назад
        </Button>
        <Button
          className="btn-glow text-primary-foreground font-medium"
          disabled={!confirmed}
          onClick={() => onNavigate("scenario-result")}
        >
          Запустить расчёт
          <Zap className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

function ScenarioResultPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const comparisonRows = [
    { param: "Итоговая сумма", base: "1 245 000 ₽", stress: "980 000 ₽", real: "1 125 000 ₽" },
    { param: "Доходность", base: "+24.5%", stress: "-2.0%", real: "+12.5%" },
    { param: "Чистый доход", base: "+182 350 ₽", stress: "-82 350 ₽", real: "+62 350 ₽" },
    { param: "Влияние комиссий", base: "-30 500 ₽", stress: "-30 500 ₽", real: "-30 500 ₽" },
    { param: "Влияние налогов", base: "-31 850 ₽", stress: "0 ₽", real: "-18 650 ₽" },
  ]

  return (
    <div className="container mx-auto max-w-7xl px-4 sm:px-6 py-8 lg:py-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold mb-1">Результат анализа</h1>
          <DisclaimerBanner compact />
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" className="border-border/50">
            <Copy className="h-4 w-4 mr-2" />
            Копировать
          </Button>
          <Button onClick={() => onNavigate("report")} variant="outline" size="sm" className="border-border/50">
            <Download className="h-4 w-4 mr-2" />
            Отчёт
          </Button>
        </div>
      </div>

      {/* Hero KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <MetricCard
          title="Базовый сценарий"
          value="1 245 000 ₽"
          trend="up"
          trendValue="+24.5%"
          subtitle="за 24 мес"
          icon={TrendingUp}
          variant="positive"
          size="large"
        />
        <MetricCard
          title="Стресс-сценарий"
          value="980 000 ₽"
          trend="down"
          trendValue="-2.0%"
          subtitle="при падении 20%"
          icon={TrendingDown}
          variant="negative"
          size="large"
        />
        <MetricCard
          title="Реальная доходность"
          value="+12.5%"
          subtitle="с учётом инфляции"
          icon={Target}
          variant="neutral"
          size="large"
        />
        <MetricCard
          title="Потери на издержках"
          value="-62 350 ₽"
          subtitle="комиссии + налоги"
          icon={Wallet}
          variant="warning"
          size="large"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Charts Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Main Chart */}
          <Card className="glass-card border-border/40">
            <CardHeader className="pb-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <CardTitle className="text-base">Динамика капитала по сценариям</CardTitle>
                <div className="flex items-center gap-4 text-xs">
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-0.5 rounded-full bg-[#22d3ee]" />
                    <span className="text-muted-foreground">Базовый</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-0.5 rounded-full bg-[#fbbf24]" />
                    <span className="text-muted-foreground">Реальный</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-0.5 rounded-full bg-[#ef4444]" style={{ borderStyle: "dashed" }} />
                    <span className="text-muted-foreground">Стресс</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={mockTimelineData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="baseGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#22d3ee" stopOpacity={0.25} />
                        <stop offset="100%" stopColor="#22d3ee" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="realGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#fbbf24" stopOpacity={0.15} />
                        <stop offset="100%" stopColor="#fbbf24" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
                    <XAxis 
                      dataKey="label" 
                      stroke="rgba(255,255,255,0.3)" 
                      fontSize={11} 
                      tickLine={false} 
                      axisLine={false}
                      dy={10}
                    />
                    <YAxis 
                      stroke="rgba(255,255,255,0.3)" 
                      fontSize={11} 
                      tickFormatter={(v) => `${(v / 1000000).toFixed(1)}M`} 
                      tickLine={false} 
                      axisLine={false}
                      dx={-10}
                    />
                    <Tooltip
                      contentStyle={{ 
                        backgroundColor: "rgba(15, 17, 25, 0.95)", 
                        border: "1px solid rgba(255,255,255,0.1)", 
                        borderRadius: "12px",
                        boxShadow: "0 20px 40px -12px rgba(0,0,0,0.5)"
                      }}
                      formatter={(value: number) => [`${value.toLocaleString()} ₽`, ""]}
                      labelStyle={{ color: "rgba(255,255,255,0.6)", marginBottom: 4 }}
                    />
                    <ReferenceLine y={1000000} stroke="rgba(255,255,255,0.1)" strokeDasharray="3 3" />
                    <Area 
                      type="monotone" 
                      dataKey="base" 
                      stroke="#22d3ee" 
                      fill="url(#baseGradient)" 
                      strokeWidth={2.5} 
                      name="Базовый"
                      dot={{ fill: "#22d3ee", strokeWidth: 0, r: 3 }}
                      activeDot={{ fill: "#22d3ee", strokeWidth: 2, stroke: "#0f1119", r: 5 }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="real" 
                      stroke="#fbbf24" 
                      fill="url(#realGradient)" 
                      strokeWidth={2} 
                      name="Реальный"
                      dot={false}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="stress" 
                      stroke="#ef4444" 
                      fill="none" 
                      strokeWidth={2} 
                      strokeDasharray="6 4" 
                      name="Стресс"
                      dot={false}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Factor Impact */}
          <Card className="glass-card border-border/40">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Влияние факторов на результат</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockFactorImpact.map((factor) => (
                  <div key={factor.factor} className="flex items-center gap-4">
                    <div className="w-32 sm:w-40 text-sm text-muted-foreground truncate">{factor.factor}</div>
                    <div className="flex-1 h-6 bg-muted/30 rounded-full overflow-hidden relative">
                      <div 
                        className="absolute top-0 bottom-0 left-0 rounded-full transition-all"
                        style={{ 
                          width: `${Math.abs(factor.percent) * 4}%`,
                          backgroundColor: factor.color,
                          opacity: 0.8
                        }}
                      />
                    </div>
                    <div className="w-24 text-right">
                      <span className="text-sm font-medium" style={{ color: factor.color }}>
                        {factor.impact.toLocaleString()} ₽
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-6 pt-4 border-t border-border/30 flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Итого издержки:</span>
                <span className="text-lg font-semibold text-red-400">
                  -{mockFactorImpact.reduce((sum, f) => sum + Math.abs(f.impact), 0).toLocaleString()} ₽
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Comparison Table */}
          <Card className="glass-card border-border/40">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Сравнение сценариев</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto -mx-6 px-6">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border/30">
                      <th className="text-left py-3 pr-4 text-xs font-medium text-muted-foreground">Показатель</th>
                      <th className="text-right py-3 px-4 text-xs font-medium text-emerald-400">
                        <div className="flex items-center justify-end gap-1.5">
                          <TrendingUp className="h-3 w-3" />
                          Базовый
                        </div>
                      </th>
                      <th className="text-right py-3 px-4 text-xs font-medium text-amber-400">
                        <div className="flex items-center justify-end gap-1.5">
                          <Minus className="h-3 w-3" />
                          Реальный
                        </div>
                      </th>
                      <th className="text-right py-3 pl-4 text-xs font-medium text-red-400">
                        <div className="flex items-center justify-end gap-1.5">
                          <TrendingDown className="h-3 w-3" />
                          Стресс
                        </div>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {comparisonRows.map((row, idx) => (
                      <tr key={row.param} className={`${idx !== comparisonRows.length - 1 ? "border-b border-border/20" : ""}`}>
                        <td className="py-3.5 pr-4 text-sm">{row.param}</td>
                        <td className="py-3.5 px-4 text-sm text-right font-medium text-emerald-400">{row.base}</td>
                        <td className="py-3.5 px-4 text-sm text-right font-medium text-amber-400">{row.real}</td>
                        <td className="py-3.5 pl-4 text-sm text-right font-medium text-red-400">{row.stress}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Sidebar */}
        <div className="space-y-4">
          {/* Risk Score */}
          <Card className="glass-card border-border/40">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Shield className="h-4 w-4 text-primary" />
                Риск-паспорт
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="flex items-center justify-center">
                <div className="relative w-32 h-32">
                  <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="8"
                      className="text-muted/30"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      fill="none"
                      stroke="url(#riskGradient)"
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={`${65 * 2.51} ${100 * 2.51}`}
                    />
                    <defs>
                      <linearGradient id="riskGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#22d3ee" />
                        <stop offset="50%" stopColor="#fbbf24" />
                        <stop offset="100%" stopColor="#ef4444" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-3xl font-bold stat-value">65</span>
                    <span className="text-xs text-muted-foreground">из 100</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Общий риск</span>
                  <RiskBadge level="medium" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Ликвидность</span>
                  <RiskBadge level="medium" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Сложность</span>
                  <RiskBadge level="low" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Risk Flags */}
          <Card className="glass-card border-border/40">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-red-400" />
                  Риск-флаги
                </CardTitle>
                <Badge className="bg-red-500/15 text-red-400 border-0 text-[10px]">
                  {riskFlags.length}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {riskFlags.map((flag) => (
                <div key={flag.text} className="flex items-start gap-3 p-3 rounded-lg bg-muted/20 border border-border/30">
                  <flag.icon className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0 space-y-1.5">
                    <p className="text-sm leading-snug">{flag.text}</p>
                    <RiskBadge level={flag.level} size="sm" />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Checklist */}
          <Card className="glass-card border-border/40">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                Что проверить
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2.5">
                {[
                  "Уточнить все комиссии у источника",
                  "Проверить условия досрочного выхода", 
                  "Оценить реальную ликвидность",
                  "Сравнить с альтернативами",
                  "Учесть личные обстоятельства"
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-sm text-muted-foreground">
                    <CircleDot className="h-3 w-3 shrink-0 mt-1 text-primary/60" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <DisclaimerBanner />
        </div>
      </div>

      {/* Bottom Actions */}
      <div className="flex flex-col sm:flex-row justify-between gap-4 mt-8 pt-8 border-t border-border/30">
        <Button variant="outline" onClick={() => onNavigate("manual-input")} className="border-border/50">
          Изменить параметры
        </Button>
        <Button className="btn-glow text-primary-foreground font-medium" onClick={() => onNavigate("report")}>
          Сформировать отчёт
          <FileText className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

function PortfolioPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  return (
    <div className="container mx-auto max-w-7xl px-4 sm:px-6 py-12">
      <div className="mb-10">
        <h1 className="text-2xl font-bold mb-2">Проверка портфеля</h1>
        <p className="text-muted-foreground">Оцените концентрацию и риск вашего портфеля</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Portfolio Table */}
          <Card className="glass-card border-border/40">
            <CardHeader className="flex flex-row items-center justify-between pb-4">
              <CardTitle className="text-base">Состав портфеля</CardTitle>
              <Button variant="outline" size="sm" className="border-border/50 h-8">
                <Plus className="h-3.5 w-3.5 mr-1.5" />
                Добавить
              </Button>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto -mx-6 px-6">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border/30">
                      <th className="text-left py-3 pr-4 text-xs font-medium text-muted-foreground">Инструмент</th>
                      <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground">Тип</th>
                      <th className="text-right py-3 px-4 text-xs font-medium text-muted-foreground">Сумма</th>
                      <th className="text-right py-3 px-4 text-xs font-medium text-muted-foreground">Доля</th>
                      <th className="text-right py-3 px-4 text-xs font-medium text-muted-foreground">YTD</th>
                      <th className="text-center py-3 pl-4 text-xs font-medium text-muted-foreground">Риск</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockPortfolioTable.map((row, idx) => (
                      <tr key={row.instrument} className={`group hover:bg-muted/20 transition-colors ${idx !== mockPortfolioTable.length - 1 ? "border-b border-border/20" : ""}`}>
                        <td className="py-3.5 pr-4">
                          <span className="font-medium text-sm">{row.instrument}</span>
                        </td>
                        <td className="py-3.5 px-4 text-sm text-muted-foreground">{row.type}</td>
                        <td className="py-3.5 px-4 text-sm text-right font-medium">{row.amount.toLocaleString()} ₽</td>
                        <td className="py-3.5 px-4 text-sm text-right">{row.share}%</td>
                        <td className={`py-3.5 px-4 text-sm text-right font-medium ${row.ytd >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                          {row.ytd >= 0 ? "+" : ""}{row.ytd}%
                        </td>
                        <td className="py-3.5 pl-4 text-center">
                          <RiskBadge level={row.risk} size="sm" />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="mt-6 pt-4 border-t border-border/30 flex items-center justify-between">
                <div>
                  <span className="text-sm text-muted-foreground">Всего:</span>
                  <span className="text-lg font-semibold ml-2">1 000 000 ₽</span>
                </div>
                <Button className="btn-glow text-primary-foreground font-medium">
                  Анализировать портфель
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Sidebar */}
        <div className="space-y-4">
          {/* Allocation Chart */}
          <Card className="glass-card border-border/40">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Распределение</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsPieChart>
                    <Pie
                      data={mockPortfolioData}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={70}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {mockPortfolioData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} stroke="transparent" />
                      ))}
                    </Pie>
                  </RechartsPieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-2 mt-4">
                {mockPortfolioData.map((item) => (
                  <div key={item.name} className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-muted-foreground">{item.name}</span>
                    </div>
                    <span className="font-medium">{item.value}%</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Risk Summary */}
          <Card className="glass-card border-border/40">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Оценка портфеля</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Диверсификация</span>
                <RiskBadge level="medium" />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Концентрация</span>
                <RiskBadge level="low" />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Ликвидность</span>
                <RiskBadge level="low" />
              </div>
            </CardContent>
          </Card>

          <DisclaimerBanner />
        </div>
      </div>
    </div>
  )
}

function KnowledgeBasePage() {
  const categories = [
    { name: "Вклады", count: 5, icon: Wallet },
    { name: "Облигации", count: 8, icon: FileText },
    { name: "Акции", count: 6, icon: TrendingUp },
    { name: "Фонды", count: 7, icon: PieChart },
    { name: "Структурные продукты", count: 4, icon: LayoutDashboard },
  ]

  return (
    <div className="container mx-auto max-w-5xl px-4 sm:px-6 py-12">
      <div className="mb-10">
        <h1 className="text-2xl font-bold mb-2">База знаний</h1>
        <p className="text-muted-foreground">Справочник по финансовым инструментам</p>
      </div>

      <div className="mb-8">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Поиск по базе знаний..." 
            className="pl-10 bg-input/50 border-border/50 h-11"
          />
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {categories.map((cat) => (
          <button
            key={cat.name}
            className="feature-card text-left p-5 rounded-xl group"
          >
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2.5 rounded-lg bg-primary/10">
                  <cat.icon className="h-4 w-4 text-primary" />
                </div>
                <Badge variant="outline" className="bg-muted/50 border-border/50 text-xs">
                  {cat.count} статей
                </Badge>
              </div>
              <h3 className="font-medium">{cat.name}</h3>
              <div className="flex items-center text-sm text-primary font-medium mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                Открыть
                <ChevronRight className="h-4 w-4 ml-1" />
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}

function ReportPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  return (
    <div className="min-h-screen bg-white text-gray-900">
      <div className="container mx-auto max-w-4xl px-4 sm:px-6 py-12">
        {/* Report Header */}
        <div className="flex items-center justify-between mb-12 print:mb-8">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cyan-50 border border-cyan-200">
              <FlaskConical className="h-5 w-5 text-cyan-600" />
            </div>
            <div>
              <h1 className="font-semibold text-lg">Scenario Lab</h1>
              <p className="text-xs text-gray-500">Отчёт по анализу сценария</p>
            </div>
          </div>
          <div className="flex items-center gap-2 print:hidden">
            <Button variant="outline" size="sm" onClick={() => onNavigate("scenario-result")}>
              Назад
            </Button>
            <Button size="sm" onClick={() => window.print()} className="bg-cyan-600 hover:bg-cyan-700 text-white">
              <Download className="h-4 w-4 mr-2" />
              Скачать PDF
            </Button>
          </div>
        </div>

        {/* Report Content */}
        <div className="space-y-8">
          <section>
            <h2 className="text-lg font-semibold mb-4 pb-2 border-b border-gray-200">Параметры анализа</h2>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Сумма инвестиций</span>
                <span className="font-medium">1 000 000 ₽</span>
              </div>
              <div className="flex justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Срок</span>
                <span className="font-medium">24 месяца</span>
              </div>
              <div className="flex justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Ожидаемая доходность</span>
                <span className="font-medium">12% годовых</span>
              </div>
              <div className="flex justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Комиссии</span>
                <span className="font-medium">1.5% годовых</span>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-4 pb-2 border-b border-gray-200">Результаты анализа</h2>
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-200">
                <p className="text-xs text-emerald-600 font-medium uppercase mb-1">Базовый</p>
                <p className="text-2xl font-bold text-emerald-700">+24.5%</p>
                <p className="text-sm text-gray-600 mt-1">1 245 000 ₽</p>
              </div>
              <div className="p-4 rounded-lg bg-amber-50 border border-amber-200">
                <p className="text-xs text-amber-600 font-medium uppercase mb-1">Реальный</p>
                <p className="text-2xl font-bold text-amber-700">+12.5%</p>
                <p className="text-sm text-gray-600 mt-1">1 125 000 ₽</p>
              </div>
              <div className="p-4 rounded-lg bg-red-50 border border-red-200">
                <p className="text-xs text-red-600 font-medium uppercase mb-1">Стресс</p>
                <p className="text-2xl font-bold text-red-700">-2.0%</p>
                <p className="text-sm text-gray-600 mt-1">980 000 ₽</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-4 pb-2 border-b border-gray-200">Риск-флаги</h2>
            <div className="space-y-2">
              {riskFlags.map((flag) => (
                <div key={flag.text} className="flex items-center gap-3 py-2 border-b border-gray-100">
                  <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                    flag.level === "high" ? "bg-red-100 text-red-700" :
                    flag.level === "medium" ? "bg-amber-100 text-amber-700" :
                    "bg-emerald-100 text-emerald-700"
                  }`}>
                    {flag.level === "high" ? "Высокий" : flag.level === "medium" ? "Средний" : "Низкий"}
                  </span>
                  <span className="text-sm">{flag.text}</span>
                </div>
              ))}
            </div>
          </section>

          <section className="p-4 bg-gray-50 rounded-lg border border-gray-200">
            <p className="text-xs text-gray-500 leading-relaxed">
              <strong>Дисклеймер:</strong> Данный отчёт носит исключительно информационный характер 
              и не является инвестиционной рекомендацией. Результаты расчёта основаны на введённых 
              данных и допущениях. Фактическая доходность может существенно отличаться.
            </p>
          </section>
        </div>

        <div className="mt-12 pt-6 border-t border-gray-200 text-center text-xs text-gray-400">
          Сформировано: {new Date().toLocaleDateString('ru-RU')} • Scenario Lab
        </div>
      </div>
    </div>
  )
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("landing")

  const handleNavigate = (page: Page) => {
    setCurrentPage(page)
    window.scrollTo(0, 0)
  }

  if (currentPage === "report") {
    return <ReportPage onNavigate={handleNavigate} />
  }

  return (
    <div className="min-h-screen bg-background">
      <TopNav currentPage={currentPage} onNavigate={handleNavigate} />
      
      {currentPage === "landing" && <LandingPage onNavigate={handleNavigate} />}
      {currentPage === "mode-selection" && <ModeSelectionPage onNavigate={handleNavigate} />}
      {currentPage === "offer-check" && <OfferCheckPage onNavigate={handleNavigate} />}
      {currentPage === "parsed-preview" && <ParsedPreviewPage onNavigate={handleNavigate} />}
      {currentPage === "assumptions" && <AssumptionsPage onNavigate={handleNavigate} />}
      {currentPage === "manual-input" && <ManualInputPage onNavigate={handleNavigate} />}
      {currentPage === "scenario-preview" && <ScenarioPreviewPage onNavigate={handleNavigate} />}
      {currentPage === "scenario-result" && <ScenarioResultPage onNavigate={handleNavigate} />}
      {currentPage === "portfolio" && <PortfolioPage onNavigate={handleNavigate} />}
      {currentPage === "knowledge-base" && <KnowledgeBasePage />}
    </div>
  )
}
