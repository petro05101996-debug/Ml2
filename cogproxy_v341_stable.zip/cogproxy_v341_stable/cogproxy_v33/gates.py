from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

from .models import AnswerContract, QualityScore, TaskProfile
from .scoring import score_answer
from .text_utils import line_dedupe, normalize, words


@dataclass(frozen=True)
class Comparison:
    improved_is_better: bool
    delta: float
    reasons: List[str]


def anti_bloat_gate(answer: str) -> str:
    """Remove obvious repeated lines and empty boilerplate.

    This gate is conservative: it does not rewrite content semantically, only
    removes duplicated lines and known filler markers.
    """
    cleaned = line_dedupe(answer)
    banned_lines = {
        "важно отметить, что",
        "следует отметить, что",
        "в целом можно сказать, что",
    }
    kept = []
    for line in cleaned.splitlines():
        if normalize(line).strip(" .:-") in banned_lines:
            continue
        kept.append(line)
    return "\n".join(kept).strip()


def salient_retention_ratio(baseline_answer: str, improved_answer: str) -> float:
    """Approximate whether an improved answer dropped most of a good baseline's content.

    This is deliberately conservative and only used as a guardrail when the
    baseline already scores high. It prevents a short template that matches
    keyword rubrics from replacing a richer expert answer.
    """
    stop = {
        "нужно", "надо", "должен", "должна", "может", "если", "тогда", "потому",
        "который", "которая", "ответ", "ответы", "модель", "модели", "сильной",
        "слабой", "сильная", "слабая", "сначала", "затем", "версию", "пользователь",
    }
    stems: list[str] = []
    for w in words(baseline_answer):
        if len(w) < 7 or w in stop or w.isdigit():
            continue
        stem = w[:8]
        if stem not in stems:
            stems.append(stem)
    if not stems:
        return 1.0
    improved = " ".join(words(improved_answer))
    retained = sum(1 for stem in stems if stem in improved)
    return retained / max(1, len(stems))


def compare_answers(
    task: TaskProfile,
    contract: AnswerContract,
    baseline_answer: str,
    improved_answer: str,
    min_delta: float = 0.03,
) -> Tuple[Comparison, QualityScore, QualityScore]:
    baseline_score = score_answer(task, contract, baseline_answer)
    improved_score = score_answer(task, contract, improved_answer)
    delta = round(improved_score.final_score - baseline_score.final_score, 3)
    reasons: List[str] = []

    if improved_score.completeness > baseline_score.completeness:
        reasons.append("covered more contract requirements")
    if improved_score.actionability > baseline_score.actionability:
        reasons.append("more actionable")
    if improved_score.depth > baseline_score.depth:
        reasons.append("deeper risk/trade-off handling")
    if improved_score.non_obvious_value > baseline_score.non_obvious_value:
        reasons.append("added non-obvious value")
    if improved_score.brevity_control < baseline_score.brevity_control - 0.15:
        reasons.append("warning: answer became bloated")

    retention = salient_retention_ratio(baseline_answer, improved_answer)
    if baseline_score.final_score >= 0.65 and retention < 0.45:
        reasons.append(f"improved answer dropped too much of an already strong baseline: retention={retention:.2f}")

    if "task grounding" in improved_score.missing and "task grounding" not in baseline_score.missing:
        reasons.append("improved answer lost grounding in the user task")
    if "domain contamination" in improved_score.missing and "domain contamination" not in baseline_score.missing:
        reasons.append("improved answer introduced off-domain meta/pipeline content")

    # Guardrail: never accept if final score is not sufficiently better, if it loses
    # too much clarity/brevity, or if it becomes off-topic while baseline stayed grounded.
    improved_is_better = (
        delta >= min_delta
        and improved_score.brevity_control >= 0.55
        and not ("task grounding" in improved_score.missing and "task grounding" not in baseline_score.missing)
        and not ("domain contamination" in improved_score.missing and "domain contamination" not in baseline_score.missing)
        and not (baseline_score.final_score >= 0.65 and retention < 0.45 and delta < 0.20)
    )
    if not improved_is_better and delta > 0:
        reasons.append("delta is positive but below release threshold or failed guardrail")
    if delta <= 0:
        reasons.append("baseline is equal or better")

    return Comparison(improved_is_better=improved_is_better, delta=delta, reasons=reasons), baseline_score, improved_score


def quality_gate(task: TaskProfile, contract: AnswerContract, answer: str, threshold: float = 0.82) -> Tuple[bool, QualityScore, List[str]]:
    score = score_answer(task, contract, answer)
    defects: List[str] = []
    if score.final_score < threshold:
        defects.append(f"final_score below threshold: {score.final_score} < {threshold}")
    if score.missing:
        defects.append("missing contract items: " + ", ".join(score.missing))
    return not defects, score, defects
