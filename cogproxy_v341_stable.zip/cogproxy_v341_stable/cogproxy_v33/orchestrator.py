from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .contract import build_answer_contract
from .gates import anti_bloat_gate, compare_answers, quality_gate
from .hybrid_path import run_hybrid_path
from .llm import DemoLLM, LLMClient
from .model_probe import probe_model_capability
from .models import Candidate, PipelineResult, StageTrace
from .scoring import score_answer
from .strong_path import run_strong_path
from .task_profile import detect_task_profile
from .weak_path import run_weak_path


@dataclass(frozen=True)
class CogProxyConfig:
    model_name: str = "unknown"
    forced_strength: Optional[str] = None  # weak | hybrid | strong
    forced_score: Optional[float] = None
    quality_threshold: float = 0.82
    min_improvement_delta: float = 0.03
    always_keep_baseline: bool = True
    # v3.4: opt-in universal directed-improver + LLM-as-judge acceptance.
    # When True, the strong path produces a contract-directed improvement and a
    # blind, position-swapped LLM judge (not the lexical scorer) decides whether
    # to release it. Off by default so existing behavior/tests are unchanged.
    #
    # RECOMMENDED for any non-architecture/general-domain use:
    #     CogProxyConfig(use_directed_improver=True, use_llm_judge=True)
    # In this mode the lexical scorer is NOT the acceptance authority and its
    # absolute numeric threshold is NOT applied (it is unreliable outside the
    # banking/architecture vocabulary). Acceptance and the no-regression
    # guarantee come from the judge; only a cheap structural grounding guardrail
    # is kept. See v3.4.1 stabilization notes.
    use_directed_improver: bool = False
    use_llm_judge: bool = False

    @classmethod
    def recommended(cls, model_name: str = "unknown", **kwargs: object) -> "CogProxyConfig":
        """Stable general-purpose configuration (judge-authoritative).

        Use this for tasks outside the banking/architecture domain, where the
        lexical scorer's absolute value cannot be trusted as a quality verdict.
        """
        params: dict = {
            "model_name": model_name,
            "use_directed_improver": True,
            "use_llm_judge": True,
        }
        params.update(kwargs)  # type: ignore[arg-type]
        return cls(**params)  # type: ignore[arg-type]


class CogProxyV33:
    def __init__(self, llm: Optional[LLMClient] = None, config: Optional[CogProxyConfig] = None) -> None:
        self.llm = llm or DemoLLM()
        self.config = config or CogProxyConfig()

    def _baseline(self, user_input: str) -> str:
        prompt = (
            "Дай первичный baseline answer без Reasoning+ усилителя. "
            "Ответь полезно, но без дополнительных циклов критики.\n"
            f"Задача пользователя: {user_input}"
        )
        return self.llm.generate(prompt, context={"stage": "baseline"}).strip()

    def run(self, user_input: str) -> PipelineResult:
        traces: list[StageTrace] = []

        task = detect_task_profile(user_input)
        traces.append(StageTrace("neutral_task_profile", "done", details={"task_type": task.task_type, "complexity": task.complexity, "classification": "disabled"}))

        contract = build_answer_contract(task)
        traces.append(StageTrace("answer_contract", "done", details={"must_have_count": len(contract.must_have)}))

        baseline = anti_bloat_gate(self._baseline(user_input))
        baseline_score = score_answer(task, contract, baseline)
        traces.append(StageTrace("baseline_answer", "done", details={"score": baseline_score.final_score}))

        model_profile = probe_model_capability(
            self.config.model_name,
            baseline,
            forced_strength=self.config.forced_strength,
            forced_score=self.config.forced_score,
        )
        traces.append(StageTrace("model_capability_probe", "done", details={"score": model_profile.capability_score, "path": model_profile.path}))

        if self.config.use_directed_improver:
            # v3.4 universal path: contract-directed improvement over the baseline,
            # works on any task regardless of model strength.
            from .improver import improve_answer
            path_answer, targeted = improve_answer(task, contract, baseline, self.llm)
            path_answer = anti_bloat_gate(path_answer)
            path_traces = [StageTrace("directed_improve", "done", details={"targeted_aspects": targeted})]
            candidates = [
                Candidate("baseline", baseline, baseline_score),
                Candidate("directed_improved", path_answer, score_answer(task, contract, path_answer)),
            ]
        elif model_profile.path == "weak":
            path_answer, path_traces, candidates = run_weak_path(task, contract, baseline, self.llm)
        elif model_profile.path == "hybrid":
            path_answer, path_traces, candidates = run_hybrid_path(task, contract, baseline, self.llm)
        else:
            path_answer, path_traces, candidates = run_strong_path(task, contract, baseline, self.llm)
        traces.extend(path_traces)

        path_answer = anti_bloat_gate(path_answer)

        if self.config.use_llm_judge:
            # Acceptance decided by blind, position-swapped LLM judge, NOT the
            # gameable lexical scorer. Scores are still computed for reporting.
            from .judge import judge_pair
            verdict = judge_pair(task, baseline, path_answer, self.llm)
            baseline_score = score_answer(task, contract, baseline)
            improved_score = score_answer(task, contract, path_answer)
            delta = round(improved_score.final_score - baseline_score.final_score, 3)
            from .gates import Comparison
            comparison = Comparison(
                improved_is_better=verdict.improved_is_better,
                delta=delta,
                reasons=["llm_judge:" + verdict.winner] + verdict.reasons,
            )
            traces.append(StageTrace("llm_judge", "done", details={"winner": verdict.winner, "order1": verdict.order1_pick, "order2": verdict.order2_pick, "accepted": verdict.improved_is_better}))
        else:
            comparison, baseline_score, improved_score = compare_answers(
                task,
                contract,
                baseline,
                path_answer,
                min_delta=self.config.min_improvement_delta,
            )
            traces.append(StageTrace("final_delta_validator", "done", details={"delta": comparison.delta, "accepted": comparison.improved_is_better, "reasons": comparison.reasons}))

        candidate_name = "improved" if comparison.improved_is_better else "baseline"
        selected = path_answer if comparison.improved_is_better else baseline

        if self.config.use_llm_judge:
            # When the blind, position-swapped LLM judge is the acceptance authority,
            # the lexical scorer must NOT re-litigate its verdict. The scorer's absolute
            # value is unreliable off-domain (it counts dictionary-word hits, so a strong
            # physics/cooking answer scores low simply for lacking architecture vocabulary),
            # which previously forced every judge-approved answer into "improved_soft_fail".
            # The no-regression guarantee is already provided by the judge: 'improved' is
            # released only if it won in BOTH orders. We still run a grounding-only guardrail
            # (a cheap structural off-topic check), but we do not apply the numeric threshold.
            final_score = score_answer(task, contract, selected)
            lost_grounding = (
                "task grounding" in improved_score.missing and "task grounding" not in baseline_score.missing
            ) or (
                "domain contamination" in improved_score.missing and "domain contamination" not in baseline_score.missing
            )
            if comparison.improved_is_better and lost_grounding:
                # Judge approved, but the structural check says the improved answer drifted
                # off-topic. Safety wins: fall back to the grounded baseline.
                selected = baseline
                candidate_name = "baseline_grounding_guardrail"
                final_score = score_answer(task, contract, selected)
            traces.append(StageTrace("acceptance_gate", "judge_authoritative", details={"score": final_score.final_score, "released": candidate_name, "grounding_guardrail": lost_grounding}))
        else:
            ok, final_score, defects = quality_gate(task, contract, selected, threshold=self.config.quality_threshold)
            traces.append(StageTrace("quality_gate", "done" if ok else "soft_fail", details={"score": final_score.final_score, "defects": defects}))

            # Safety property: even if the selected improved answer fails the target threshold,
            # do not return worse than baseline. If baseline is also below threshold, return the
            # better of the two and report the soft_fail trace.
            if not ok and comparison.improved_is_better:
                # If the improved answer is off-topic, prefer the grounded baseline even when
                # a heuristic numeric score says otherwise. This protects strong models from
                # domain-regression caused by a generic improvement template.
                if ("task grounding" in improved_score.missing and "task grounding" not in baseline_score.missing) or ("domain contamination" in improved_score.missing and "domain contamination" not in baseline_score.missing):
                    selected = baseline
                    candidate_name = "baseline_grounding_guardrail"
                else:
                    selected = path_answer if improved_score.final_score >= baseline_score.final_score else baseline
                    candidate_name = "improved_soft_fail" if selected == path_answer else "baseline_soft_fail"
                final_score = score_answer(task, contract, selected)

        all_candidates: list[Candidate] = candidates[:]
        if not any(c.name == "baseline" for c in all_candidates):
            all_candidates.insert(0, Candidate("baseline", baseline, baseline_score))

        return PipelineResult(
            final_answer=selected,
            baseline_answer=baseline,
            selected_answer_name=candidate_name,
            path=model_profile.path,
            improved=comparison.improved_is_better,
            baseline_score=baseline_score,
            final_score=final_score,
            model_profile=model_profile,
            task_profile=task,
            answer_contract=contract,
            traces=traces,
            candidates=all_candidates,
        )
