from __future__ import annotations

from typing import List

from .gates import anti_bloat_gate, compare_answers
from .llm import LLMClient
from .models import AnswerContract, Candidate, StageTrace, TaskProfile
from .scoring import score_answer
from .strong_path import run_strong_path
from .text_utils import join_sections
from .weak_path import run_weak_path


def run_hybrid_path(task: TaskProfile, contract: AnswerContract, baseline_answer: str, llm: LLMClient) -> tuple[str, List[StageTrace], List[Candidate]]:
    weak_answer, weak_traces, weak_candidates = run_weak_path(task, contract, baseline_answer, llm)
    strong_answer, strong_traces, strong_candidates = run_strong_path(task, contract, baseline_answer, llm)

    merged = join_sections([
        ("Сильная часть structured path", weak_answer),
        ("Сильная часть expert amplifier", strong_answer),
        ("Финальное правило", "Наружу отдаётся только версия, которая лучше baseline по comparative_judge; иначе fallback к baseline."),
    ])
    merged = anti_bloat_gate(merged)

    comparison, _, _ = compare_answers(task, contract, baseline_answer, merged)
    traces: List[StageTrace] = []
    traces.extend(StageTrace("hybrid." + t.stage, t.status, t.iteration, t.details) for t in weak_traces)
    traces.extend(StageTrace("hybrid." + t.stage, t.status, t.iteration, t.details) for t in strong_traces)
    traces.append(StageTrace("hybrid_merge", "done", details={"accepted": comparison.improved_is_better, "delta": comparison.delta}))

    candidates = weak_candidates + strong_candidates + [Candidate("hybrid_merged", merged, score_answer(task, contract, merged))]
    return (merged if comparison.improved_is_better else baseline_answer), traces, candidates
