from __future__ import annotations

from typing import Optional

from .models import ModelProfile, ReasoningPath
from .text_utils import contains_any, words


def choose_path(score: float) -> ReasoningPath:
    if score < 0.65:
        return "weak"
    if score < 0.85:
        return "hybrid"
    return "strong"


def probe_model_capability(
    model_name: str,
    baseline_answer: str,
    forced_strength: Optional[str] = None,
    forced_score: Optional[float] = None,
) -> ModelProfile:
    """Estimate model strength.

    In production, pass a stored model profile or run a small benchmark outside this
    function. This fallback uses deterministic answer-quality signals so tests and
    local demos are reproducible.
    """
    if forced_strength:
        mapping = {"weak": 0.55, "hybrid": 0.75, "medium": 0.75, "strong": 0.9}
        score = mapping.get(forced_strength, 0.75)
        return ModelProfile(name=model_name, capability_score=score, path=choose_path(score), reasons=[f"forced_strength={forced_strength}"])

    if forced_score is not None:
        score = max(0.0, min(1.0, forced_score))
        return ModelProfile(name=model_name, capability_score=score, path=choose_path(score), reasons=[f"forced_score={score}"])

    token_count = len(words(baseline_answer))
    score = 0.45
    reasons = []
    if token_count > 80:
        score += 0.15
        reasons.append("baseline has enough substance")
    if contains_any(baseline_answer, ["риск", "trade-off", "альтернатив", "почему", "baseline", "порог"]):
        score += 0.15
        reasons.append("baseline mentions reasoning markers")
    if contains_any(baseline_answer, ["сделай", "шаг", "внедри", "проверь", "план"]):
        score += 0.10
        reasons.append("baseline is actionable")
    if contains_any(baseline_answer, ["не ухудш", "сравн", "качество", "критер"]):
        score += 0.10
        reasons.append("baseline has self-evaluation hints")
    score = max(0.0, min(1.0, score))
    return ModelProfile(name=model_name, capability_score=round(score, 3), path=choose_path(score), reasons=reasons or ["fallback heuristic"])
