from __future__ import annotations

from typing import Dict, List

from .gates import anti_bloat_gate, quality_gate
from .llm import LLMClient
from .models import AnswerContract, Candidate, StageTrace, TaskProfile
from .scoring import score_answer
from .text_utils import join_sections


def _repair_missing(answer: str, missing: List[str]) -> str:
    if not missing:
        return answer
    additions = ["## Доработка по пропущенным критериям"]
    for item in missing:
        if "baseline" in item:
            additions.append("- Baseline comparison: перед усилением сохраняем исходный ответ и сравниваем финальную версию с ним.")
        elif "anti-bloat" in item:
            additions.append("- Anti-bloat: удаляем повторы и абзацы, которые не добавляют решения, риска, примера или следующего шага.")
        elif "quality" in item:
            additions.append("- Quality gate: финальный ответ должен пройти порог качества по полноте, конкретике, действию и глубине.")
        elif "defect" in item:
            additions.append("- Defect return: каждый дефект возвращается на ответственный этап, а не исправляется случайно в конце.")
        elif "слаб" in item or "сильн" in item:
            additions.append("- Адаптация: слабая модель получает жесткие поля, сильная — свободный baseline, критику и альтернативы.")
        elif "регресс" in item:
            additions.append("- Проверка на регрессию: если improved не лучше baseline, наружу уходит baseline.")
        else:
            additions.append(f"- {item}: добавить отдельный проверяемый блок в ответ.")
    return answer.rstrip() + "\n\n" + "\n".join(additions)


def run_weak_path(task: TaskProfile, contract: AnswerContract, baseline_answer: str, llm: LLMClient) -> tuple[str, List[StageTrace], List[Candidate]]:
    traces: List[StageTrace] = []
    state: Dict[str, object] = {}

    state["context_capture"] = {
        "goal": task.user_goal,
        "task_type": task.task_type,
        "must_have": contract.must_have,
    }
    traces.append(StageTrace("context_capture", "done"))

    state["structure"] = {
        "paths": ["weak_model_path", "strong_model_path"],
        "gates": ["quality_gate", "anti_bloat_gate", "baseline_vs_improved_judge"],
    }
    traces.append(StageTrace("structure", "done"))

    state["relation"] = {
        "weak_model_path": "compensates lack of reasoning with explicit fields",
        "strong_model_path": "raises ceiling with critique and alternatives",
        "judge": "prevents regression against baseline",
    }
    traces.append(StageTrace("relation", "done"))

    solution = join_sections([
        ("Решение", "Сделать adaptive Reasoning+: сначала получить baseline, затем построить answer_contract, выбрать weak/hybrid/strong path и выпустить только ответ, который проходит comparative_judge."),
        ("Для слабой модели", "Использовать жесткий graph-state: context_capture → structure → relation → solution → attack → validation → synthesis. Каждый этап заполняет малые поля, дефекты возвращаются в ответственный граф."),
        ("Для сильной модели", "Не зажимать модель шаблоном. Дать свободный baseline, затем expert_critique, orthogonal angles, challenger answer, anti-bloat и сравнение с baseline."),
        ("Quality gate", "Проверять completeness, specificity, depth, actionability, clarity, non_obvious_value и brevity_control. Если score ниже порога — repair или fallback."),
        ("Практический порядок внедрения", "1. Добавить baseline_answer.\n2. Добавить answer_contract.\n3. Реализовать adaptive_mode.\n4. Реализовать comparative_judge.\n5. Добавить anti-bloat.\n6. Закрыть regression tests."),
    ])
    traces.append(StageTrace("solution", "done"))

    attack_findings = []
    ok, q, defects = quality_gate(task, contract, solution, threshold=0.80)
    if not ok:
        attack_findings.extend(defects)
    traces.append(StageTrace("attack", "done", details={"findings": attack_findings}))

    if q.missing:
        solution = _repair_missing(solution, q.missing)
        traces.append(StageTrace("defect_return", "done", details={"target_stage": "solution", "missing": q.missing}))

    solution = anti_bloat_gate(solution)
    traces.append(StageTrace("validation", "done", details={"score": score_answer(task, contract, solution).final_score}))
    traces.append(StageTrace("synthesis", "done"))

    candidates = [
        Candidate("baseline", baseline_answer, score_answer(task, contract, baseline_answer)),
        Candidate("weak_structured", solution, score_answer(task, contract, solution)),
    ]
    return solution, traces, candidates
