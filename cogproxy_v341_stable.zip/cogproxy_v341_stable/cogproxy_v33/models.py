from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Literal, Optional

ReasoningPath = Literal["weak", "hybrid", "strong"]


@dataclass(frozen=True)
class TaskProfile:
    task_type: str
    user_goal: str
    domain: str
    complexity: str
    requires_fresh_data: bool = False
    keywords: List[str] = field(default_factory=list)


@dataclass(frozen=True)
class AnswerContract:
    task_type: str
    quality_target: str
    must_have: List[str]
    fatal_misses: List[str]
    success_criteria: List[str]
    anti_patterns: List[str]
    improvement_target: str = "improved answer must beat baseline or baseline is returned"


@dataclass(frozen=True)
class ModelProfile:
    name: str
    capability_score: float
    path: ReasoningPath
    reasons: List[str] = field(default_factory=list)


@dataclass(frozen=True)
class QualityScore:
    correctness: float
    completeness: float
    specificity: float
    depth: float
    actionability: float
    clarity: float
    non_obvious_value: float
    brevity_control: float
    final_score: float
    missing: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class Candidate:
    name: str
    answer: str
    score: QualityScore
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class StageTrace:
    stage: str
    status: str
    iteration: int = 1
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class PipelineResult:
    final_answer: str
    baseline_answer: str
    selected_answer_name: str
    path: ReasoningPath
    improved: bool
    baseline_score: QualityScore
    final_score: QualityScore
    model_profile: ModelProfile
    task_profile: TaskProfile
    answer_contract: AnswerContract
    traces: List[StageTrace]
    candidates: List[Candidate]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
