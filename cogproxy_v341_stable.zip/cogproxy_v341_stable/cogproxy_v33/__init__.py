"""CogProxy v3.3 Adaptive Expert Amplifier.

This package is intentionally stdlib-only. Plug any LLM behind `LLMClient` or
`SubprocessLLM` and run the adaptive pipeline.
"""

from .orchestrator import CogProxyV33, CogProxyConfig
from .models import PipelineResult, TaskProfile, ModelProfile, AnswerContract, QualityScore

__all__ = [
    "CogProxyV33",
    "CogProxyConfig",
    "PipelineResult",
    "TaskProfile",
    "ModelProfile",
    "AnswerContract",
    "QualityScore",
]
