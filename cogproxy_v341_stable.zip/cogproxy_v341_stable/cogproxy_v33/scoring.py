from __future__ import annotations

import re
from typing import Dict, Iterable, List, Tuple

from .models import AnswerContract, QualityScore, TaskProfile
from .text_utils import clamp, contains_any, duplicate_line_ratio, normalize, words

CONCEPT_SYNONYMS: Dict[str, List[str]] = {
    "главный принцип решения": ["главный принцип", "суть", "принцип", "основа"],
        "baseline comparison": ["baseline", "базов", "исходн", "сравн", "лучше первого"],
    "quality gate": ["quality gate", "гейт", "порог качества", "не выпуск", "валидац"],
    "anti-bloat": ["anti-bloat", "вода", "раздут", "лишн", "сжат", "удлинение"],
        "практический порядок внедрения": ["порядок", "шаг", "внедр", "сначала", "потом", "приоритет"],
    "главный инвариант": ["инвариант", "главное условие", "клиент", "корректный статус", "истина"],
    "границы ответственности": ["ответствен", "границ", "банк", "ук", "владелец", "source of truth"],
    "статусная модель": ["статус", "state", "new", "processing", "success", "fail", "pending"],
    "контракты событий": ["контракт", "event", "событ", "schema", "версионир", "payload"],
    "идемпотентность outbox inbox": ["идемпотент", "outbox", "inbox", "eventid", "dedup", "дубл"],
    "порядок и ключ партиционирования": ["поряд", "ключ", "partition", "партиц", "operationid", "applicationid", "ordering", "orderid", "deviceid", "attemptid", "returnid", "tenantid", "ticketid", "seatid"],
    "retry dlq": ["retry", "ретра", "повтор", "dlq", "dead letter", "ошиб"],
    "reconciliation": ["reconciliation", "сверк", "рассинхрон", "компенс", "переобработ"],
    "observability": ["observability", "монитор", "лог", "метрик", "alert", "трасс", "correlation"],
    "tradeoffs": ["trade-off", "компромисс", "плюс", "минус", "альтернатив", "не надо", "дороже", "достаточно", "сложн"],
    "минимально достаточная архитектура": ["минимально", "достаточ", "не усложн", "без лишн", "прост", "mvp", "на старте"],
    "проверка на регрессию": ["регресс", "не хуже", "fallback", "откат", "тест"],
    "цель": ["цель", "инвариант", "outcome"],
    "сегменты пользователей": ["сегмент", "junior", "middle", "senior", "пользователь", "корпоратив"],
    "core loop": ["core loop", "цикл", "кейс", "повтор", "попытк", "feedback"],
    "ценность продукта": ["ценность", "платит", "платн", "рост навыка", "за что"],
    "mvp": ["mvp", "минимальн", "10 кейс", "первую версию"],
    "метрики": ["метрик", "retention", "conversion", "конверси", "nps", "completion"],
    "диагностика текущей позиции": ["диагност", "текущ", "позици"],
    "рыночные варианты": ["рынок", "вариант"],
    "план действий": ["план", "шаг"],
    "риски": ["риск"],
    "критерии выбора": ["критер", "выбор"],
    "варианты": ["вариант", "альтернатив"],
    "проверка отзывов": ["отзыв", "провер"],
    "итоговый выбор": ["итог", "лучший", "выбор"],
    "маршрут": ["маршрут"],
    "логистика": ["логист", "добраться", "транспорт"],
    "бюджет": ["бюджет", "стоим", "руб"],
    "приоритеты": ["приоритет", "сначала"],
    "запасные варианты": ["запас", "альтернатив"],
    "прямой ответ": ["ответ", "вывод", "суть", "решение"],
    "исходные условия": ["исходн", "вводн", "услов", "контекст", "огранич"],
    "критерии качества": ["критер", "качест", "оцен", "провер", "метрик"],
    "обоснование": ["почему", "обосн", "так как", "потому"],
    "практические шаги": ["шаг", "сделай", "внедри"],
    "риски и ограничения": ["риск", "огранич", "но", "если", "опас", "минус"],
    "альтернативы": ["альтернатив", "вариант", "иначе", "или"],
    "проверка результата": ["провер", "тест", "валид", "критер", "метрик"],
    "итоговый вывод": ["итог", "вывод", "значит", "коротко", "главное"],
    "граница актуальности данных": ["актуальн", "свеж", "на дату", "проверить", "источник"],
    "ограничения": ["огранич", "риск", "но", "если"],
}

ACTION_WORDS = [
    "сдел", "добав", "внедр", "проверь", "проверк", "запусти", "сравн", "удали", "верни",
    "раздел", "задай", "собер", "создай", "измер", "постав", "фиксир", "начать",
    "вычитать", "сохран", "публиков", "валид", "примен", "запис", "монитор",
]
DEPTH_WORDS = [
    "trade-off", "компромисс", "риск", "альтернатив", "инвариант", "отказ", "регресс",
    "границ", "критик", "валид", "сравн", "порог", "fallback",
]
INSIGHT_WORDS = [
    "не ухудш", "baseline", "ортогональ", "anti-bloat", "сильную модель нельзя",
    "повышать потолок", "компенсировать слабость", "соревноваться с собой", "дельта",
    "fallback", "non-obvious", "challenger",
    # Architecture-level non-obvious value markers
    "источник истины", "главный инвариант", "не должен просто", "только если",
    "не гарантирует бизнес-полноту", "избыточ", "нормализ", "доказуем",
    "переобработ", "не переводят",
]
CLARITY_MARKERS = ["##", "1.", "2.", "- ", "```", ":"]


STOPWORDS = {
    "нужно", "надо", "чтобы", "сделай", "сделать", "как", "что", "это", "для", "при", "или", "если", "тебе",
    "мне", "меня", "твой", "твою", "ответ", "ответы", "качество", "вариант", "варианты", "выбор", "найди",
    "дай", "бюджет", "бюджетом", "руб", "рублей", "реально", "хороший", "лучший", "кратно", "повысить",
    "модель", "модели", "слабая", "сильная", "сильной", "слабой", "тоже", "уже"
}

DOMAIN_GROUNDING_REQUIRED = {"universal_task"}
DOMAIN_META_TERMS = [
    "cogproxy", "reasoning+", "llm", "baseline", "quality gate", "anti-bloat",
    "weak_model_path", "strong_model_path", "adaptive classifier", "classifier", "классификатор",
    "challenger answer", "comparative_judge", "score dashboard"
]



def _is_meta_quality_request(user_text: str) -> bool:
    return contains_any(user_text, [
        "cogproxy", "llm", "reasoning", "модель", "модели",
        "качество ответ", "усилитель", "baseline", "quality gate",
        "слабая модель", "сильная модель",
    ])


def _important_task_terms(task: TaskProfile) -> List[str]:
    # No domain classifier: grounding uses important terms directly from the user request.
    terms: List[str] = []
    for w in task.keywords:
        if w in STOPWORDS:
            continue
        if len(w) < 4 and not any(ch.isdigit() for ch in w):
            continue
        # keep a short stem so Russian case endings do not break relevance matching
        if any(ch.isdigit() for ch in w):
            stem = w
        elif len(w) >= 7:
            stem = w[:5]
        else:
            stem = w[:4]
        if stem not in terms:
            terms.append(stem)
    return terms[:10]


def _task_grounding(task: TaskProfile, answer: str) -> Tuple[float, List[str]]:
    """Check that an answer is about the user's actual task, not only about generic quality words."""
    terms = _important_task_terms(task)
    if not terms or task.task_type not in DOMAIN_GROUNDING_REQUIRED or _is_meta_quality_request(normalize(task.user_goal)):
        return 1.0, []
    text = normalize(answer)
    compact_text = re.sub(r"\s+", "", text)
    missing = []
    for t in terms:
        if any(ch.isdigit() for ch in t):
            if t not in compact_text:
                missing.append(t)
        elif t not in text:
            missing.append(t)
    matched = len(terms) - len(missing)
    # Require at least one hard entity for domain tasks. This catches off-topic templates.
    score = matched / max(1, len(terms))
    return score, missing


def _coverage(answer: str, concepts: Iterable[str]) -> Tuple[float, List[str]]:
    missing: List[str] = []
    concepts = list(concepts)
    if not concepts:
        return 1.0, []
    for concept in concepts:
        needles = CONCEPT_SYNONYMS.get(concept, [concept])
        if not contains_any(answer, needles):
            missing.append(concept)
    covered = len(concepts) - len(missing)
    return covered / max(1, len(concepts)), missing


def score_answer(task: TaskProfile, contract: AnswerContract, answer: str) -> QualityScore:
    text = answer or ""
    token_count = len(words(text))
    coverage, missing = _coverage(text, contract.must_have)
    grounding, grounding_missing = _task_grounding(task, text)
    # Off-domain contamination: a car/travel/career answer must not be filled with
    # CogProxy/LLM-pipeline mechanics unless the user actually asked about them.
    user_text = normalize(task.user_goal)
    contamination_hits = [] if _is_meta_quality_request(user_text) else [term for term in DOMAIN_META_TERMS if term in normalize(text) and term not in user_text]

    fatal_hits = [m for m in contract.fatal_misses if contains_any(text, [m])]
    # Do not reward stating fatal misses as plain text, but penalize empty/generic answers.
    correctness = 0.92 if token_count >= 35 else 0.45
    if fatal_hits:
        correctness -= 0.08

    actionability = clamp(sum(1 for w in ACTION_WORDS if contains_any(text, [w])) / 6)
    depth = clamp(sum(1 for w in DEPTH_WORDS if contains_any(text, [w])) / 7)
    insight = clamp(sum(1 for w in INSIGHT_WORDS if contains_any(text, [w])) / 5)

    concrete_markers = len(re.findall(r"\b\d+[.)]?|v\d|score|threshold|pytest|json|cli|gate|baseline", normalize(text)))
    specificity = clamp((concrete_markers / 10) + (0.25 if task.complexity == "high" and token_count > 120 else 0))

    clarity = clamp((sum(1 for m in CLARITY_MARKERS if m in text) / 5) + (0.25 if 80 <= token_count <= 900 else 0))

    dup_ratio = duplicate_line_ratio(text)
    too_short_penalty = 0.35 if token_count < 45 else 0.0
    too_long_penalty = 0.2 if token_count > 1600 else 0.0
    brevity_control = clamp(1.0 - dup_ratio - too_short_penalty - too_long_penalty)

    completeness = coverage

    weights = {
        "correctness": 0.14,
        "completeness": 0.22,
        "specificity": 0.13,
        "depth": 0.14,
        "actionability": 0.14,
        "clarity": 0.08,
        "non_obvious_value": 0.10,
        "brevity_control": 0.05,
    }
    raw_final = (
        correctness * weights["correctness"]
        + completeness * weights["completeness"]
        + specificity * weights["specificity"]
        + depth * weights["depth"]
        + actionability * weights["actionability"]
        + clarity * weights["clarity"]
        + insight * weights["non_obvious_value"]
        + brevity_control * weights["brevity_control"]
    )

    # Domain answers must stay grounded in the user task. A generic CogProxy-quality answer
    # must not beat a real car/travel/career answer just because it mentions "criteria",
    # "risks", "check" or "final".
    if task.task_type in DOMAIN_GROUNDING_REQUIRED:
        final = raw_final * (0.45 + 0.55 * grounding)
        if grounding < 0.34 and "task grounding" not in missing:
            missing = missing + ["task grounding"]
        if len(contamination_hits) >= 3:
            final *= 0.45
            if "domain contamination" not in missing:
                missing = missing + ["domain contamination"]
    else:
        final = raw_final

    notes = []
    if dup_ratio > 0.05:
        notes.append(f"duplicate_line_ratio={dup_ratio:.2f}")
    if task.task_type in DOMAIN_GROUNDING_REQUIRED:
        notes.append(f"task_grounding={grounding:.2f}")
        if grounding_missing:
            notes.append("grounding_missing=" + ", ".join(grounding_missing[:8]))
        if contamination_hits:
            notes.append("domain_contamination=" + ", ".join(contamination_hits[:8]))
    if missing:
        notes.append("missing=" + ", ".join(missing))

    return QualityScore(
        correctness=round(clamp(correctness), 3),
        completeness=round(completeness, 3),
        specificity=round(specificity, 3),
        depth=round(depth, 3),
        actionability=round(actionability, 3),
        clarity=round(clarity, 3),
        non_obvious_value=round(insight, 3),
        brevity_control=round(brevity_control, 3),
        final_score=round(clamp(final), 3),
        missing=missing,
        notes=notes,
    )
