from __future__ import annotations

from .models import AnswerContract, TaskProfile


def build_answer_contract(task: TaskProfile) -> AnswerContract:
    """Build one universal answer contract instead of classification by domain.

    The contract is intentionally domain-neutral. It tells each graph what a good
    answer must contain without deciding whether the task is architecture,
    finance, learning, code review, shopping, etc.
    """
    must_have = [
        "прямой ответ",
        "исходные условия",
        "критерии качества",
        "обоснование",
        "риски и ограничения",
        "альтернативы",
        "практические шаги",
        "проверка результата",
        "итоговый вывод",
    ]
    if task.requires_fresh_data:
        must_have.append("граница актуальности данных")

    fatal_misses = [
        "нет ответа на главный вопрос",
        "пересказ вопроса без решения",
        "общие слова без конкретных действий",
        "неподтвержденные числа",
        "игнорирование ограничений пользователя",
        "ухудшение baseline без явного выигрыша",
    ]
    success = [
        "ответ решает задачу пользователя без доменной подмены",
        "важные исходные условия сохранены",
        "есть критерии качества, риски, альтернативы и практические действия",
        "финальная версия не выпускается, если она хуже baseline",
    ]
    anti_patterns = [
        "task-classifier выбирает домен по ключевым словам",
        "ответ подменяет задачу шаблоном CogProxy/архитектуры",
        "удлинение ответа без новой пользы",
        "финальный ответ не сравнен с baseline",
    ]
    return AnswerContract(
        task_type=task.task_type,
        quality_target="expert",
        must_have=must_have,
        fatal_misses=fatal_misses,
        success_criteria=success,
        anti_patterns=anti_patterns,
    )
