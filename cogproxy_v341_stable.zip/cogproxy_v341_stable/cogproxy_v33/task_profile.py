from __future__ import annotations

from .models import TaskProfile
from .text_utils import contains_any, words


def detect_task_profile(user_input: str) -> TaskProfile:
    """Build a neutral task profile without domain classification.

    v3.3.6 deliberately does NOT classify the request as architecture / career /
    recommendation / product / etc. Earlier versions had a task classifier and it
    produced false positives ("продукты" -> "ук", "ответы" -> LLM-quality).

    The pipeline now uses one universal quality contract and relies on graph
    stages + defect repair, not a domain classifier.
    """
    tokens = words(user_input)
    text = " ".join(tokens)
    complexity = "high" if len(tokens) > 45 or contains_any(
        text,
        [
            "сложн", "кратно", "универс", "сильн", "слаб", "граф",
            "kafka", "статус", "интеграц", "договор", "финанс", "стратег",
            "код", "тест", "план", "риски", "сравн", "объектив",
        ],
    ) else "medium"
    requires_fresh = contains_any(
        text,
        ["сегодня", "сейчас", "последн", "цена", "налич", "новост", "расписан", "курс", "актуальн"],
    )

    return TaskProfile(
        task_type="universal_task",
        user_goal=user_input.strip(),
        domain="universal",
        complexity=complexity,
        requires_fresh_data=requires_fresh,
        keywords=tokens[:80],
    )
