"""LLM-as-judge with bias safeguards.

Replaces the gameable lexical scorer as the *acceptance authority* for the
amplifier. The lexical scorer counts dictionary-word hits and is trivially
beaten by keyword salad, so it must not be the final arbiter of "is this
answer better". This judge asks a real model to compare two answers on
task-specific quality, with four safeguards against known LLM-judge biases:

1. BLINDNESS      — the judge never learns which answer is the baseline.
2. POSITION SWAP  — every pair is judged twice, in both orders. "Improved
                    wins" only if it wins in BOTH orders. Disagreement = tie.
                    This neutralises the first-position preference.
3. ANTI-VERBOSITY — the rubric explicitly tells the judge that longer is not
                    better; pick the shorter answer when length adds no
                    task-relevant precision. Counters the length bias that
                    would otherwise rubber-stamp our (longer) improved answers.
4. HIGH BAR       — anything other than an unambiguous double-win returns the
                    baseline. Preserves the no-regression guarantee: when
                    unsure, do not change the answer.

The judge is the SAME model by default (cheap, no second endpoint). The
safeguards are what make same-model judging trustworthy enough; without them,
do not use this.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional

from .llm import LLMClient
from .models import TaskProfile


@dataclass(frozen=True)
class JudgeVerdict:
    improved_is_better: bool
    winner: str  # "improved" | "baseline" | "tie"
    order1_pick: str  # what the judge picked in order (baseline, improved)
    order2_pick: str  # what the judge picked in order (improved, baseline)
    reasons: List[str]


_JUDGE_INSTRUCTIONS = (
    "Ты строгий судья качества ответов. Перед тобой задача пользователя и два ответа: ОТВЕТ 1 и ОТВЕТ 2.\n"
    "Выбери, какой ответ ЛУЧШЕ решает именно эту задачу пользователя.\n\n"
    "Правила оценки:\n"
    "- Оценивай по существу задачи: верность, конкретность, полнота по сути, практическая применимость.\n"
    "- Более длинный ответ НЕ считается лучшим. Если длинный ответ не добавляет точности и пользы "
    "по сути задачи, выбирай более короткий.\n"
    "- Вода, общие фразы, повторы и набор правильно звучащих слов без смысла — это ХУЖЕ, а не лучше.\n"
    "- Если ответ подменяет задачу пользователя посторонним содержанием — он хуже.\n"
    "- Если разницы по сути нет — это ничья.\n\n"
    "Ответь СТРОГО одним словом на отдельной строке: '1', '2' или 'tie'. "
    "Затем при желании одну строку с кратким обоснованием.\n"
)


def _build_prompt(task: TaskProfile, first: str, second: str) -> str:
    return (
        _JUDGE_INSTRUCTIONS
        + f"\nЗАДАЧА ПОЛЬЗОВАТЕЛЯ:\n{task.user_goal}\n\n"
        + f"ОТВЕТ 1:\n{first}\n\n"
        + f"ОТВЕТ 2:\n{second}\n\n"
        + "Твой вердикт (1 / 2 / tie):"
    )


def _parse_pick(raw: str) -> str:
    """Extract '1' | '2' | 'tie' from the judge's reply. Defaults to 'tie' if unclear."""
    if not raw:
        return "tie"
    # First non-empty line carries the verdict.
    for line in raw.strip().splitlines():
        token = line.strip().lower()
        if not token:
            continue
        if token.startswith("tie") or "ничья" in token:
            return "tie"
        m = re.match(r"[^\d]*([12])\b", token)
        if m:
            return m.group(1)
        # if the first content line wasn't parseable, keep scanning a couple lines
    # Fallback: search whole text
    if "ничья" in raw.lower() or "tie" in raw.lower():
        return "tie"
    m = re.search(r"\b([12])\b", raw)
    return m.group(1) if m else "tie"


def judge_pair(
    task: TaskProfile,
    baseline_answer: str,
    improved_answer: str,
    llm: LLMClient,
) -> JudgeVerdict:
    """Blind, position-swapped, double-run comparison.

    Returns improved_is_better=True ONLY if 'improved' wins in both orders.
    """
    # If the amplifier produced no actual change, short-circuit to a tie:
    # no point spending judge calls, and we must not "win" against ourselves.
    if (improved_answer or "").strip() == (baseline_answer or "").strip():
        return JudgeVerdict(False, "tie", "tie", "tie", ["no change vs baseline"])

    # Order 1: (baseline=1, improved=2)
    raw1 = llm.generate(_build_prompt(task, baseline_answer, improved_answer), context={"stage": "judge", "order": 1})
    pick1 = _parse_pick(raw1)
    order1_pick = {"1": "baseline", "2": "improved", "tie": "tie"}[pick1]

    # Order 2: (improved=1, baseline=2) — positions swapped
    raw2 = llm.generate(_build_prompt(task, improved_answer, baseline_answer), context={"stage": "judge", "order": 2})
    pick2 = _parse_pick(raw2)
    order2_pick = {"1": "improved", "2": "baseline", "tie": "tie"}[pick2]

    reasons: List[str] = [f"order1_pick={order1_pick}", f"order2_pick={order2_pick}"]

    if order1_pick == "improved" and order2_pick == "improved":
        return JudgeVerdict(True, "improved", order1_pick, order2_pick, reasons + ["improved won in both orders"])
    if order1_pick == "baseline" and order2_pick == "baseline":
        return JudgeVerdict(False, "baseline", order1_pick, order2_pick, reasons + ["baseline won in both orders"])
    # Disagreement between orders (position bias suspected) or any tie -> tie, keep baseline.
    return JudgeVerdict(False, "tie", order1_pick, order2_pick, reasons + ["inconsistent across orders or tie -> keep baseline"])
