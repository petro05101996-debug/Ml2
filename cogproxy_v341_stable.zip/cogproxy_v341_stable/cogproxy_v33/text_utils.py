from __future__ import annotations

import re
from collections import Counter
from typing import Iterable, List, Sequence

_WORD_RE = re.compile(r"[A-Za-zА-Яа-яЁё0-9_+-]+", re.U)


def normalize(text: str) -> str:
    return (text or "").strip().lower().replace("ё", "е")


def words(text: str) -> List[str]:
    return _WORD_RE.findall(normalize(text))


def contains_any(text: str, needles: Iterable[str]) -> bool:
    t = normalize(text)
    return any(normalize(n) in t for n in needles)


def line_dedupe(text: str) -> str:
    seen = set()
    result = []
    for raw in (text or "").splitlines():
        line = raw.rstrip()
        key = normalize(re.sub(r"\s+", " ", line))
        if not key:
            if result and result[-1] == "":
                continue
            result.append("")
            continue
        if key in seen:
            continue
        seen.add(key)
        result.append(line)
    return "\n".join(result).strip()


def duplicate_line_ratio(text: str) -> float:
    lines = [normalize(l) for l in (text or "").splitlines() if normalize(l)]
    if not lines:
        return 0.0
    counts = Counter(lines)
    duplicate_count = sum(c - 1 for c in counts.values() if c > 1)
    return duplicate_count / max(1, len(lines))


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def join_sections(sections: Sequence[tuple[str, str]]) -> str:
    chunks = []
    for title, body in sections:
        body = (body or "").strip()
        if not body:
            continue
        chunks.append(f"## {title}\n{body}")
    return "\n\n".join(chunks).strip()


def extract_sentences(text: str) -> List[str]:
    parts = re.split(r"(?<=[.!?])\s+|\n+", text or "")
    return [p.strip() for p in parts if p.strip()]
