from __future__ import annotations

import argparse
import json
import sys

from .llm import DemoLLM, SubprocessLLM
from .orchestrator import CogProxyConfig, CogProxyV33


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="CogProxy v3.3 Adaptive Expert Amplifier")
    parser.add_argument("input", nargs="*", help="User task. If empty, stdin is used.")
    parser.add_argument("--model-strength", choices=["weak", "hybrid", "medium", "strong"], default=None)
    parser.add_argument("--model-name", default="demo")
    parser.add_argument("--llm-cmd", nargs="+", help="External LLM command. Prompt is sent to stdin.")
    parser.add_argument("--json", action="store_true", help="Print full JSON result instead of only final answer.")
    args = parser.parse_args(argv)

    user_input = " ".join(args.input).strip() or sys.stdin.read().strip()
    if not user_input:
        parser.error("input is required")

    llm = SubprocessLLM(args.llm_cmd) if args.llm_cmd else DemoLLM()
    proxy = CogProxyV33(
        llm=llm,
        config=CogProxyConfig(model_name=args.model_name, forced_strength=args.model_strength),
    )
    result = proxy.run(user_input)
    if args.json:
        print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
    else:
        print(result.final_answer)
        print("\n---")
        print(f"path={result.path}; selected={result.selected_answer_name}; baseline_score={result.baseline_score.final_score}; final_score={result.final_score.final_score}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
