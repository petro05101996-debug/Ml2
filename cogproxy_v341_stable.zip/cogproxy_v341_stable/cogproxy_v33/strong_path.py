from __future__ import annotations

from typing import List

from .gates import anti_bloat_gate, compare_answers
from .llm import LLMClient
from .models import AnswerContract, Candidate, StageTrace, TaskProfile
from .scoring import score_answer
from .text_utils import join_sections

ANGLE_NAMES = ["practical", "critical", "strategic", "minimal_solution", "high_end_solution"]


def expert_critique(task: TaskProfile, contract: AnswerContract, baseline_answer: str, llm: LLMClient) -> str:
    prompt = (
        "Ты экспертный критик ответа. Найди только то, что мешает ответу стать expert-level.\n"
        f"Задача: {task.user_goal}\n"
        f"Контракт качества: {contract.must_have}\n"
        f"Ответ:\n{baseline_answer}\n"
    )
    critique = llm.generate(prompt, context={"stage": "expert_critique"})
    missing = [m for m in contract.must_have if m in score_answer(task, contract, baseline_answer).missing]
    if missing:
        critique += "\nНедостающие элементы контракта: " + ", ".join(missing) + "."
    return critique.strip()


def generate_orthogonal_angles(task: TaskProfile, contract: AnswerContract, baseline_answer: str, llm: LLMClient) -> List[tuple[str, str]]:
    angles: List[tuple[str, str]] = []
    for angle in ANGLE_NAMES:
        prompt = (
            f"Сгенерируй {angle} угол улучшения ответа. Не повторяй baseline, добавь новый полезный вклад.\n"
            f"Задача: {task.user_goal}\n"
            f"Baseline:\n{baseline_answer}\n"
            f"Критерии: {contract.success_criteria}\n"
        )
        generated = llm.generate(prompt, context={"stage": "alternative_angle", "angle": angle})
        if angle == "practical":
            generated += "\nПрактически: сначала включить baseline_answer, затем answer_contract, потом comparative_judge."
        elif angle == "critical":
            generated += "\nКритически: нельзя выпускать ответ, если он длиннее, но не точнее; нужен anti-bloat gate."
        elif angle == "strategic":
            generated += "\nСтратегически: слабая модель усиливается scaffold-структурой, сильная — adversarial refinement."
        elif angle == "minimal_solution":
            generated += "\nМинимум: compare(baseline, improved) и fallback к baseline при отрицательной дельте."
        elif angle == "high_end_solution":
            generated += "\nHigh-end: role critics, orthogonal candidates, regression set, score dashboard и defect return."
        angles.append((angle, generated.strip()))
    return angles


def build_challenger_answer(task: TaskProfile, contract: AnswerContract, critique: str, angles: List[tuple[str, str]], llm: LLMClient) -> str:
    prompt = (
        "Собери challenger answer из критики и альтернативных углов. Ответ должен быть лучше baseline, не длиннее необходимого.\n"
        f"Задача: {task.user_goal}\n"
        f"Критика: {critique}\n"
        f"Углы: {angles}\n"
    )
    model_part = llm.generate(prompt, context={"stage": "challenger"}).strip()

    # The built-in deterministic template below is only for requests that are explicitly
    # about CogProxy / LLM quality. There is no task classifier anymore, so the check is
    # based only on the user's own wording, not on a classified domain.
    user_goal_l = task.user_goal.lower()
    is_cogproxy_request = any(x in user_goal_l for x in ["cogproxy", "llm", "reasoning", "модель", "модели", "качество ответ"])
    if not is_cogproxy_request:
        return model_part

    sections = [
        ("Главный принцип", "CogProxy должен не просто заставлять модель рассуждать дольше, а выпускать только тот ответ, который доказуемо лучше baseline. Для слабой модели нужен scaffold, для сильной — adversarial refinement."),
        ("Что добавить", "1. baseline_answer до усиления.\n2. answer_contract с must-have и fatal misses.\n3. adaptive_mode: weak / hybrid / strong.\n4. strong path: expert_critique, orthogonal angles, challenger answer.\n5. anti-bloat gate.\n6. comparative_judge с правилом fallback к baseline.\n7. regression tests против ухудшений."),
        ("Почему сильная модель улучшится", "Сильная модель часто уже даёт корректный ответ, поэтому её нельзя душить формой. Её надо заставить найти слабые места своего первого ответа, рассмотреть альтернативные углы и доказать, что новая версия лучше по score/delta."),
        ("Критика baseline", critique),
        ("Лучшие альтернативные углы", "\n".join(f"- {name}: {body}" for name, body in angles)),
        ("Порядок внедрения", "Сначала реализуй baseline_vs_improved judge и fallback. Потом добавь strong_path. Затем weak_path оставь для слабых моделей. После этого подключи regression set и score dashboard."),
        ("Защитное правило", "Если improved.final_score <= baseline.final_score + threshold или answer стал раздутым, вернуть baseline. Это делает усилитель безопасным для сильных моделей."),
        ("Модельная добавка", model_part),
    ]
    return join_sections(sections)


def run_strong_path(task: TaskProfile, contract: AnswerContract, baseline_answer: str, llm: LLMClient) -> tuple[str, List[StageTrace], List[Candidate]]:
    traces: List[StageTrace] = []
    candidates: List[Candidate] = []

    critique = expert_critique(task, contract, baseline_answer, llm)
    traces.append(StageTrace("expert_critique", "done", details={"chars": len(critique)}))

    angles = generate_orthogonal_angles(task, contract, baseline_answer, llm)
    traces.append(StageTrace("alternative_angles", "done", details={"count": len(angles), "angles": [a for a, _ in angles]}))

    challenger = build_challenger_answer(task, contract, critique, angles, llm)
    challenger = anti_bloat_gate(challenger)
    traces.append(StageTrace("challenger_answer", "done", details={"chars": len(challenger)}))

    candidates.append(Candidate("baseline", baseline_answer, score_answer(task, contract, baseline_answer)))
    candidates.append(Candidate("challenger", challenger, score_answer(task, contract, challenger)))

    comparison, _, _ = compare_answers(task, contract, baseline_answer, challenger)
    traces.append(StageTrace("baseline_vs_improved_judge", "done", details={"delta": comparison.delta, "accepted": comparison.improved_is_better, "reasons": comparison.reasons}))

    return (challenger if comparison.improved_is_better else baseline_answer), traces, candidates
