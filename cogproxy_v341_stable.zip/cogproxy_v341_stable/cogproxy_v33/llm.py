from __future__ import annotations

import subprocess
from dataclasses import dataclass
from typing import Callable, Mapping, Optional, Protocol


class LLMClient(Protocol):
    def generate(self, prompt: str, *, context: Optional[Mapping[str, object]] = None) -> str:
        ...


@dataclass
class FunctionLLM:
    fn: Callable[[str], str]

    def generate(self, prompt: str, *, context: Optional[Mapping[str, object]] = None) -> str:
        return self.fn(prompt)


@dataclass
class SubprocessLLM:
    """Adapter for a terminal LLM command.

    Example:
        llm = SubprocessLLM(["my-llm-cli", "--model", "x"])
        answer = llm.generate("prompt")

    The prompt is sent through stdin. Stdout is used as the answer.
    """

    command: list[str]
    timeout_seconds: int = 120

    def generate(self, prompt: str, *, context: Optional[Mapping[str, object]] = None) -> str:
        proc = subprocess.run(
            self.command,
            input=prompt,
            text=True,
            capture_output=True,
            timeout=self.timeout_seconds,
            check=False,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"LLM command failed with code {proc.returncode}: {proc.stderr.strip()}")
        return proc.stdout.strip()


class DemoLLM:
    """Deterministic local LLM substitute for tests/demos.

    This is not a real model. It makes the package runnable without API keys.
    Replace with FunctionLLM/SubprocessLLM in production.
    """

    def generate(self, prompt: str, *, context: Optional[Mapping[str, object]] = None) -> str:
        p = prompt.lower()
        if "baseline" in p or "первичный" in p:
            return (
                "Нужно добавить граф рассуждений, проверку качества и итерации. "
                "Для слабой модели полезна структура, а для сильной — критика и альтернативы. "
                "Итоговый ответ надо проверять перед выдачей пользователю."
            )
        if "critic" in p or "критик" in p:
            return "Не хватает baseline comparison, anti-bloat, явного fallback и проверки регрессии."
        if "angle" in p or "угол" in p:
            return "Сравни практический, критический, стратегический и минимальный варианты, затем собери лучшие части."
        return "Добавь adaptive mode selector, quality gate, baseline comparison, anti-bloat gate, defect return и regression tests."
