"""Universal contract-directed improver.

The old strong path produced "improvement" by asking the model to critique
itself and emit a fresh answer. For non-CogProxy tasks that fresh answer was
just raw model text, so any gain depended entirely on the model spontaneously
doing better — which it rarely did, hence the constant fallback to baseline.

This improver is *directed*: it tells the model exactly which contract
requirements the current answer leaves unraised, and asks it to raise ONLY
those, by adding genuine substance, without repeating what's already there and
without padding. The list of unmet requirements comes from the existing
lexical scorer's `missing` output — used here not as a quality verdict (it's
gameable for that) but as a cheap, reasonable signal of "what's structurally
absent". Whether the result is actually better is decided by the LLM judge,
not by this signal.

This works on ANY task because the contract is domain-neutral. Its ceiling is
the model: it can make a lazy model less lazy, but it cannot inject expertise
the model lacks. That is the honest limit of the universal approach.
"""
from __future__ import annotations

from typing import List

from .llm import LLMClient
from .models import AnswerContract, TaskProfile
from .scoring import score_answer


_IMPROVE_INSTRUCTIONS = (
    "Ты улучшаешь свой собственный ответ на задачу пользователя. Тебе дан текущий ответ и список "
    "аспектов, которые в нём раскрыты слабо или отсутствуют.\n\n"
    "Сделай ОДНО: дополни ответ по существу именно по этим аспектам.\n\n"
    "Жёсткие правила:\n"
    "- Не повторяй то, что уже сказано. Добавляй только новое содержание.\n"
    "- Каждое дополнение должно быть конкретным и относиться к ЗАДАЧЕ ПОЛЬЗОВАТЕЛЯ, а не к общим словам.\n"
    "- Не лей воду. Если по аспекту нечего сказать предметно — лучше не трогай его, чем добавляй пустоту.\n"
    "- Не меняй тему. Не подменяй задачу пользователя посторонним содержанием.\n"
    "- Сохрани всё полезное из текущего ответа.\n"
    "- Длина ради длины запрещена: больше текста ≠ лучше.\n\n"
    "Верни ПОЛНЫЙ улучшенный ответ целиком (а не только дополнения), готовый к выдаче пользователю.\n"
)


def _unmet_requirements(task: TaskProfile, contract: AnswerContract, answer: str) -> List[str]:
    """Which contract must-have items the current answer leaves unraised.

    Uses the lexical scorer's coverage check as a cheap structural signal.
    Filters out the meta markers ('task grounding', 'domain contamination')
    which are guardrail flags, not content requirements.
    """
    score = score_answer(task, contract, answer)
    meta = {"task grounding", "domain contamination"}
    return [m for m in score.missing if m not in meta]


def improve_answer(
    task: TaskProfile,
    contract: AnswerContract,
    answer: str,
    llm: LLMClient,
) -> tuple[str, List[str]]:
    """Produce a directed improvement of `answer`.

    Returns (improved_answer, targeted_aspects). If nothing is unmet, returns
    the answer unchanged with an empty target list — the caller/judge will then
    naturally keep the baseline.
    """
    unmet = _unmet_requirements(task, contract, answer)
    if not unmet:
        return answer, []

    aspects = "\n".join(f"- {item}" for item in unmet)
    prompt = (
        _IMPROVE_INSTRUCTIONS
        + f"\nЗАДАЧА ПОЛЬЗОВАТЕЛЯ:\n{task.user_goal}\n\n"
        + f"ТЕКУЩИЙ ОТВЕТ:\n{answer}\n\n"
        + f"АСПЕКТЫ ДЛЯ ДОРАБОТКИ (раскрой по существу, без воды):\n{aspects}\n\n"
        + "Полный улучшенный ответ:"
    )
    improved = llm.generate(prompt, context={"stage": "directed_improve", "aspects": unmet}).strip()
    # Defensive: if the model returned something empty or trivially short, keep original.
    if len(improved) < max(20, int(0.5 * len(answer.strip()))):
        return answer, unmet
    return improved, unmet
