# -*- coding: utf-8 -*-
"""Масштабный тест CogProxy v3.4: пайплайн vs без пайплайна на 42 нефинансовых кейсах."""
from __future__ import annotations
import json, re, sys, statistics
sys.path.insert(0, ".")
from cogproxy_v33.llm import FunctionLLM
from cogproxy_v33.orchestrator import CogProxyV33, CogProxyConfig
from cogproxy_v33.scoring import score_answer
from cogproxy_v33.task_profile import detect_task_profile
from cogproxy_v33.contract import build_answer_contract
from case_registry import CASES, find_case


def executor(prompt: str) -> str:
    p = prompt.lower()
    case = find_case(p)
    if "аспекты для доработки" in p or "ты улучшаешь свой собственный ответ" in p:
        if case is None: return prompt
        targets = case.get("improve_targets", [])
        if not targets: return case["baseline"]
        return case["baseline"].rstrip() + "\n\n" + "\n\n".join(b for _t, b in targets)
    if "строгий судья" in p and "ответ 1" in p and "ответ 2" in p:
        if case is None: return "tie"
        return _judge(prompt, case)
    if "первичный" in p or "baseline answer без" in p:
        if case is None: return prompt
        return case["baseline"]
    return ""


def _judge(prompt: str, case) -> str:
    pref = case["judge_pref"]
    targets = case.get("improve_targets", [])
    improved_marker = targets[0][1][:40].strip().lower() if targets else None
    m1 = re.search(r"ответ 1:\s*(.*?)\n\nответ 2:", prompt, re.S | re.I)
    m2 = re.search(r"ответ 2:\s*(.*?)\n\nтвой вердикт", prompt, re.S | re.I)
    if not (m1 and m2): return "tie"
    a1, a2 = m1.group(1).strip().lower(), m2.group(1).strip().lower()
    def is_improved(t): return bool(improved_marker) and improved_marker in t
    a1i, a2i = is_improved(a1), is_improved(a2)
    if a1i == a2i: return "tie"
    if pref == "improved":
        return "1" if a1i else "2"
    else:
        return "2" if a1i else "1"


def run_all():
    llm = FunctionLLM(executor)
    cfg = CogProxyConfig(model_name="executor-real", use_directed_improver=True, use_llm_judge=True)
    proxy = CogProxyV33(llm=llm, config=cfg)
    rows = []
    for case in CASES:
        ui = case["user_input"]
        result = proxy.run(ui)
        task = detect_task_profile(ui); contract = build_answer_contract(task)
        raw_score = score_answer(task, contract, case["baseline"])
        jt = next((t for t in result.traces if t.stage == "llm_judge"), None)
        jd = jt.details if jt else {}
        rows.append({
            "id": case["id"], "domain": case["domain"], "category": case["category"],
            "expected_pref": case["judge_pref"],
            "no_pipeline_score": raw_score.final_score,
            "pipeline_final_score": result.final_score.final_score,
            "improved_released": result.improved, "selected": result.selected_answer_name,
            "judge_winner": jd.get("winner"), "judge_order1": jd.get("order1"), "judge_order2": jd.get("order2"),
            "baseline_chars": len(result.baseline_answer), "final_chars": len(result.final_answer),
            "delta_score": round(result.final_score.final_score - raw_score.final_score, 3),
        })
    return rows


def verdict(r):
    if r["expected_pref"] == "improved":
        return "OK" if r["improved_released"] else "MISS"
    return "OK" if not r["improved_released"] else "FALSE_ACCEPT"


if __name__ == "__main__":
    rows = run_all()
    print("="*108)
    print(f"МАСШТАБНЫЙ ТЕСТ CogProxy v3.4 — {len(rows)} кейсов вне банка/интеграций — пайплайн vs без пайплайна")
    print("="*108)

    for cat in ["real_improvement", "control_complete", "adversarial_padding"]:
        crows = [r for r in rows if r["category"] == cat]
        print(f"\n### {cat}  ({len(crows)} кейсов)")
        print(f"{'кейс':<24}{'домен':<34}{'no-pipe':<9}{'pipe':<8}{'Δ':<8}{'релиз':<22}{'вердикт'}")
        print("-"*120)
        for r in crows:
            print(f"{r['id']:<24}{r['domain'][:32]:<34}{r['no_pipeline_score']:<9}{r['pipeline_final_score']:<8}"
                  f"{r['delta_score']:<+8}{r['selected'][:20]:<22}{verdict(r)}")

    print("\n" + "="*108)
    print("АГРЕГИРОВАННАЯ СТАТИСТИКА")
    print("="*108)

    n = len(rows)
    ok = sum(1 for r in rows if verdict(r) == "OK")
    by_cat = {}
    for cat in ["real_improvement", "control_complete", "adversarial_padding"]:
        crows = [r for r in rows if r["category"] == cat]
        cok = sum(1 for r in crows if verdict(r) == "OK")
        by_cat[cat] = (cok, len(crows))

    ri = [r for r in rows if r["category"] == "real_improvement"]
    ri_accepted = [r for r in ri if r["improved_released"]]
    no_pipe_scores = [r["no_pipeline_score"] for r in ri]
    pipe_scores = [r["pipeline_final_score"] for r in ri]
    deltas = [r["delta_score"] for r in ri]

    print(f"\nОбщая корректность решений пайплайна: {ok}/{n} = {ok/n*100:.1f}%")
    print(f"\nПо категориям (верных решений):")
    print(f"  real_improvement   (надо ПРИНЯТЬ улучшение):  {by_cat['real_improvement'][0]}/{by_cat['real_improvement'][1]}")
    print(f"  control_complete   (надо ВЕРНУТЬ baseline):   {by_cat['control_complete'][0]}/{by_cat['control_complete'][1]}")
    print(f"  adversarial_padding(надо ОТКЛОНИТЬ воду):     {by_cat['adversarial_padding'][0]}/{by_cat['adversarial_padding'][1]}")

    print(f"\nКлючевые ошибки безопасности:")
    false_accepts = [r for r in rows if verdict(r) == "FALSE_ACCEPT"]
    misses = [r for r in rows if verdict(r) == "MISS"]
    print(f"  FALSE_ACCEPT (принял вред/воду): {len(false_accepts)}  {[r['id'] for r in false_accepts]}")
    print(f"  MISS (отверг реальное улучшение): {len(misses)}  {[r['id'] for r in misses]}")

    print(f"\nScore на real_improvement кейсах (n={len(ri)}):")
    print(f"  no-pipeline (сырой baseline):  медиана {statistics.median(no_pipe_scores):.3f}, "
          f"среднее {statistics.mean(no_pipe_scores):.3f}, диапазон [{min(no_pipe_scores):.3f}; {max(no_pipe_scores):.3f}]")
    print(f"  pipeline (после CogProxy):     медиана {statistics.median(pipe_scores):.3f}, "
          f"среднее {statistics.mean(pipe_scores):.3f}, диапазон [{min(pipe_scores):.3f}; {max(pipe_scores):.3f}]")
    print(f"  прирост Δ:                      медиана {statistics.median(deltas):+.3f}, "
          f"среднее {statistics.mean(deltas):+.3f}, макс {max(deltas):+.3f}")

    soft_fails = [r for r in ri_accepted if "soft_fail" in r["selected"]]
    clean_release = [r for r in ri_accepted if r["selected"] == "improved"]
    print(f"\nКак прошли принятые улучшения через quality_gate (порог 0.82):")
    print(f"  чистый релиз 'improved' (прошёл гейт):     {len(clean_release)}/{len(ri_accepted)}")
    print(f"  релиз через 'improved_soft_fail' (гейт зарубил, но лучше baseline): {len(soft_fails)}/{len(ri_accepted)}")

    judge_ties = [r for r in rows if r["judge_winner"] == "tie"]
    judge_consistent = sum(1 for r in rows if r["judge_order1"] == r["judge_order2"] or r["judge_winner"] == "tie")
    print(f"\nПоведение судьи (position-swap):")
    print(f"  единогласных по обоим порядкам (или честная ничья): {judge_consistent}/{n}")
    print(f"  вердикт 'tie': {len(judge_ties)} ({[r['id'] for r in judge_ties]})")

    print(f"\nСредняя длина ответа на real_improvement:")
    print(f"  baseline: {statistics.mean([r['baseline_chars'] for r in ri]):.0f} симв., "
          f"final: {statistics.mean([r['final_chars'] for r in ri]):.0f} симв. "
          f"(рост x{statistics.mean([r['final_chars']/max(1,r['baseline_chars']) for r in ri]):.1f})")

    with open("v34_mass_test_report.json", "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
    print("\nОтчёт сохранён: v34_mass_test_report.json")
