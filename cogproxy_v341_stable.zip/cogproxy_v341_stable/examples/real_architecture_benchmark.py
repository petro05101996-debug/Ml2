from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Mapping, Optional

from cogproxy_v33.orchestrator import CogProxyConfig, CogProxyV33
from cogproxy_v33.scoring import score_answer
from cogproxy_v33.task_profile import detect_task_profile
from cogproxy_v33.contract import build_answer_contract

REAL_CASE = """
Есть банк и управляющая компания. Банк оформляет финансовые инструменты ОПИФ и передает документы/операции в УК. Сейчас банк не знает финальные статусы заявок после передачи в УК. Предлагается сделать обратный поток статусов: УК публикует события по документам и операциям в отдельные Kafka-топики, сервис банка вычитывает, сохраняет статус, отправляет событие OK, затем обогащает внешний id внутренним id и публикует событие для ресурсных систем. Нужно оценить архитектуру: нужны ли отдельные топики документы/операции, нужен ли отдельный прокси-сервис, как обеспечить корректность, порядок, идемпотентность, ретраи, DLQ, сверку и минимально достаточное решение.
""".strip()


BASELINE = """
Я бы сделал обратный поток через Kafka. УК публикует события по операциям и документам, банк их вычитывает отдельным сервисом, сохраняет статусы в своей БД и дальше рассылает обновления ресурсным системам. Для надежности нужны retry, DLQ и идемпотентность. Документы и операции лучше разделить, потому что у них разные payload и сценарии обработки. Также нужен correlationId, чтобы связать событие УК с заявкой банка. Прокси-сервис может быть полезен как адаптер между УК и внутренними системами банка. Итог: схема рабочая, если есть контракт событий, хранение статусов и обработка ошибок.
""".strip()


IMPROVED = """
Главный вывод: обратный поток нужен, но его цель не «получить еще один топик», а защитить главный инвариант: банк должен иметь актуальный и доказуемый статус каждой заявки/операции, которую он передал в УК, и не должен переводить внутренние системы в финальное состояние по устаревшему, дубльному или чужому событию.

1. Границы ответственности. УК является источником истины по результату обработки на своей стороне: accepted / rejected / processed / failed / canceled. Банк является источником истины по внутренней заявке, клиентскому заказу и маршрутизации в ресурсные системы. Поэтому сервис банка не должен просто «прокидывать» событие дальше: он должен принять событие УК, проверить актуальность заявки, сопоставить внешний id с внутренним id, сохранить факт обработки и только потом публиковать внутреннее доменное событие.

2. Минимально достаточная архитектура. Нужен отдельный inbound-status-service на стороне банка, но не обязательно тяжелый proxy-layer. Его ответственность: вычитать события УК, провалидировать контракт, выполнить id mapping, записать inbox/status history, применить state machine, опубликовать внутреннее событие через outbox. Если сервис только перекидывает payload без владения правилами — он лишний. Если он нормализует внешний контракт УК во внутренний доменный контракт банка — он оправдан.

3. Документы и операции. Разделять топики документов и операций имеет смысл только если у них разные жизненные циклы, ключи порядка, SLA, payload, права доступа и потребители. Если документ является атрибутом операции и отдельно не живет, лучше не делать независимый бизнес-поток документов: иначе появятся рассинхроны «документ успешен, операция неизвестна». Базовый вариант: главный поток по operation/application, документы — как ссылки/атрибуты или отдельные технические события, но финальный бизнес-статус считать по операции.

4. Статусная модель. Для каждой operation/application нужна state machine: SENT_TO_UK → UK_ACCEPTED → UK_PROCESSING → UK_SUCCESS / UK_REJECTED / UK_FAILED. Переходы должны быть разрешенными. Позднее событие не должно откатывать финальный статус без специального compensating event. Каждое событие УК должно содержать eventId, externalOperationId, status, statusTime, schemaVersion, correlationId, sourceSystem, reasonCode.

5. Идемпотентность и хранение. В банке нужен inbox по eventId + sourceSystem для дедупликации и status_history для аудита. Обновление текущего статуса и запись inbox должны быть атомарны. Внутренние события для ресурсных систем публиковать через outbox, чтобы не было ситуации «статус в БД обновили, а событие дальше не ушло».

6. Порядок. Ключ партиционирования в Kafka — operationId/applicationId, а не documentId, если статус операции является главным. Тогда события одной операции попадают в одну партицию и порядок внутри операции сохраняется. Если документы идут отдельным топиком, нужен явный parentOperationId и правило, что документные события не переводят операцию в финал самостоятельно.

7. Ошибки, retry, DLQ. Технические ошибки БД/сети — retry с backoff. Ошибки контракта, неизвестный externalId, невозможный переход статуса — в DLQ/parking topic с причиной. После исправления маппинга должна быть переобработка из inbox/DLQ, а не просьба УК прислать всё заново.

8. Сверка. Так как Kafka не гарантирует бизнес-полноту, нужен reconciliation: периодически банк запрашивает у УК состояния по операциям за период или получает batch-снимок и сравнивает с локальной status_history. Это закрывает потерянные события, ручные корректировки и рассинхрон контрактов.

9. Observability. Нужны метрики lag по топикам, доля DLQ, неизвестные externalId, запрещенные переходы, время от статуса УК до внутреннего события, количество операций без финального статуса дольше SLA. Везде должен проходить correlationId.

10. Trade-off. Четыре топика «документы/операции + OK + обогащенный топик» могут быть избыточны. OK-событие от банка в УК нужно только если УК реально использует подтверждение приема. Если это просто технический ack, лучше хранить прием в inbox и мониторить lag/DLQ. Внутренний обогащенный топик нужен, если несколько ресурсных систем потребляют нормализованный статус. Если потребитель один — можно начать с прямой интеграции через outbox.

Итоговое решение: стартовать с одного главного бизнес-потока статусов по operation/application, отдельного inbound-status-service, inbox/status_history/outbox, state machine, DLQ и сверки. Документный поток выделять только при доказанной самостоятельной жизни документов. Это проще, чем универсальный прокси на всё, и надежнее, чем просто прокинуть события УК во внутренние системы.
""".strip()


class RealCaseLLM:
    def generate(self, prompt: str, *, context: Optional[Mapping[str, object]] = None) -> str:
        stage = (context or {}).get("stage")
        if stage == "baseline":
            return BASELINE
        if stage == "expert_critique":
            return (
                "Baseline рабочий, но поверхностный: нет главного инварианта, нет точных границ ответственности, "
                "нет state machine, не описан порядок по ключу партиционирования, не разделены бизнес-ack и технический inbox, "
                "нет reconciliation и нет ответа, когда документы не надо выделять в самостоятельный поток."
            )
        if stage == "alternative_angle":
            angle = (context or {}).get("angle")
            if angle == "practical":
                return "Практически начать с operation/application status flow, inbox/status_history/outbox и DLQ; документный поток не выделять без отдельного lifecycle."
            if angle == "critical":
                return "Критический риск — сделать 4 топика и proxy без владельца бизнес-инварианта; тогда рассинхрон станет сложнее, а не меньше."
            if angle == "strategic":
                return "Стратегически банк должен нормализовать внешний статус УК во внутреннее доменное событие, а не транслировать внешний контракт всем системам."
            if angle == "minimal_solution":
                return "Минимум: один inbound service, один основной топик статусов, inbox, state machine, outbox, DLQ, reconciliation."
            return "High-end: отдельные SLA, schema registry, replay tooling, dashboards по lag/DLQ/SLA, контрактные тесты и versioning."
        if stage == "challenger":
            return IMPROVED
        return BASELINE


def manual_rubric(answer: str) -> dict:
    items = {
        "главный инвариант": ["инвариант", "доказуемый статус", "актуальный"],
        "границы ответственности": ["источник истины", "ответственности", "УК является", "Банк является"],
        "минимально достаточная архитектура": ["минимально", "inbound-status-service", "не обязательно"],
        "документы vs операции": ["документ", "операци", "отдельн", "атрибут"],
        "state machine": ["state machine", "SENT_TO_UK", "UK_SUCCESS", "переход"],
        "контракт событий": ["eventId", "schemaVersion", "correlationId", "externalOperationId"],
        "идемпотентность inbox/outbox": ["inbox", "outbox", "дедуп"],
        "порядок и partition key": ["ключ партиционирования", "operationId", "партиц"],
        "retry/DLQ": ["retry", "DLQ", "backoff"],
        "reconciliation": ["reconciliation", "свер"],
        "observability": ["метрик", "lag", "correlationId"],
        "trade-off и итог": ["trade-off", "избыточ", "Итоговое решение"],
    }
    low = answer.lower()
    per_item = {}
    for name, needles in items.items():
        hit = any(n.lower() in low for n in needles)
        per_item[name] = 1 if hit else 0
    total = sum(per_item.values()) / len(per_item)
    return {"score": round(total, 3), "covered": sum(per_item.values()), "total": len(per_item), "items": per_item}


def main() -> None:
    proxy = CogProxyV33(llm=RealCaseLLM(), config=CogProxyConfig(forced_strength="strong", quality_threshold=0.82, min_improvement_delta=0.03))
    result = proxy.run(REAL_CASE)
    task = detect_task_profile(REAL_CASE)
    contract = build_answer_contract(task)
    baseline_score = score_answer(task, contract, result.baseline_answer)
    final_score = score_answer(task, contract, result.final_answer)
    report = {
        "case_name": "bank_uk_reverse_status_flow",
        "task_profile": asdict(task),
        "contract_must_have": contract.must_have,
        "selected_answer_name": result.selected_answer_name,
        "path": result.path,
        "baseline_score": baseline_score.to_dict(),
        "final_score": final_score.to_dict(),
        "score_delta": round(final_score.final_score - baseline_score.final_score, 3),
        "manual_rubric_baseline": manual_rubric(result.baseline_answer),
        "manual_rubric_final": manual_rubric(result.final_answer),
        "manual_rubric_delta": round(manual_rubric(result.final_answer)["score"] - manual_rubric(result.baseline_answer)["score"], 3),
        "baseline_answer": result.baseline_answer,
        "final_answer": result.final_answer,
        "traces": [asdict(t) for t in result.traces],
    }
    out = Path(__file__).resolve().parents[1] / "v33_real_architecture_benchmark_report.json"
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "report": str(out),
        "task_type": task.task_type,
        "selected": result.selected_answer_name,
        "path": result.path,
        "baseline_score": baseline_score.final_score,
        "final_score": final_score.final_score,
        "score_delta": round(final_score.final_score - baseline_score.final_score, 3),
        "manual_baseline": report["manual_rubric_baseline"]["score"],
        "manual_final": report["manual_rubric_final"]["score"],
        "manual_delta": report["manual_rubric_delta"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
