from cogproxy_v33 import CogProxyConfig, CogProxyV33

proxy = CogProxyV33(config=CogProxyConfig(forced_strength="strong"))
result = proxy.run("Нужно чтобы и сильная модель улучшала ответы CogProxy")

print(result.final_answer)
print("---")
print("path:", result.path)
print("baseline_score:", result.baseline_score.final_score)
print("final_score:", result.final_score.final_score)
print("selected:", result.selected_answer_name)
