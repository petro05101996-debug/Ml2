#!/usr/bin/env python3
"""
Blind A/B efficacy harness for CogProxy.

PURPOSE
-------
Answer the only question that matters: does the pipeline make a REAL model's
answers better than that same model's raw (baseline) answer?

The repo's existing benchmark cannot answer this — it feeds a hardcoded
"improved" string as the model output, so it only proves "if the model emits
this exact expert text, the pipeline keeps it". This harness instead runs a
live model, captures (a) its raw baseline answer and (b) the post-pipeline
answer, and writes them out as BLIND, SHUFFLED pairs for an external judge.

Crucially it does NOT use CogProxy's own scorer to declare a winner — that
scorer is gameable by keyword density (verified separately). The verdict must
come from outside: a human, or a different judge model.

USAGE
-----
1. Plug in your real model. Two options:

   A) CLI model (prompt via stdin, answer via stdout):
        python examples/blind_ab_efficacy.py \
            --llm-cmd my-llm-cli --model x \
            --strength strong

   B) Python callable: edit `build_llm()` below to return a FunctionLLM
      wrapping your API call.

2. The script runs every task through the pipeline, capturing baseline vs final.

3. It writes two files:
   - ab_pairs_blind.jsonl   : one row per task, options A/B shuffled, key hidden
   - ab_answer_key.json     : maps each task -> which of A/B was the pipeline output

4. Score it WITHOUT the scorer:
   - Hand `ab_pairs_blind.jsonl` to a human or a judge model. For each task they
     pick the better answer (A, B, or tie) on task-specific quality — does it
     actually solve THIS problem, with correct specifics, no padding.
   - Then run:  python examples/blind_ab_efficacy.py --grade graded.jsonl
     where graded.jsonl has rows {"task_id": ..., "winner": "A"|"B"|"tie"}.
     The script joins against the key and reports the real win rate.

WHAT "EFFICACY" MEANS HERE
--------------------------
- win  : pipeline output judged better than raw baseline  -> pipeline added value
- tie  : no judged difference                             -> pipeline added nothing (but cost tokens)
- loss : raw baseline judged better                       -> pipeline HURT (should be ~0 given the no-regression guarantee)

A pipeline that mostly ties is not "improving answers" — it's spending
compute to reformat. Only a meaningful win rate, with near-zero losses,
demonstrates real efficacy.
"""
from __future__ import annotations

import argparse
import json
import random
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Callable, List, Mapping, Optional

from cogproxy_v33.orchestrator import CogProxyConfig, CogProxyV33
from cogproxy_v33.llm import FunctionLLM, SubprocessLLM


# ----------------------------------------------------------------------------
# Task set. Replace/extend with YOUR real tasks. Keep them domain-varied so the
# result isn't just "good on the one architecture case the system was tuned on".
# Each task should be a real request a user might send.
# ----------------------------------------------------------------------------
DEFAULT_TASKS: List[dict] = [
    {
        "id": "bank_uk_status",
        "prompt": (
            "Есть банк и УК. Банк передаёт операции ОПИФ в УК и не знает финальные "
            "статусы. Нужен обратный поток статусов через Kafka: отдельные топики, "
            "корректность, порядок, идемпотентность, retry, DLQ, сверка. Оцени "
            "архитектуру и предложи минимально достаточное решение."
        ),
    },
    {
        "id": "car_budget_rf",
        "prompt": "Найди вариант надёжной машины в РФ с бюджетом 500000 рублей. Объясни критерии и риски.",
    },
    {
        "id": "exam_platform",
        "prompt": (
            "Спроектируй платформу онлайн-экзамена: автосохранение ответов студента, "
            "устойчивость к обрыву связи, защита от потери данных. Что критично?"
        ),
    },
    {
        "id": "outbox_vs_cdc",
        "prompt": (
            "Объясни, когда для надёжной публикации событий из сервиса лучше "
            "transactional outbox, а когда CDC через Debezium. Дай критерии выбора."
        ),
    },
    {
        "id": "dinner_list",
        "prompt": "Составь список продуктов на ужин на двоих: паста с курицей и салат. Уложись в простой набор.",
    },
    {
        "id": "iis_strategy",
        "prompt": (
            "Стоит ли открывать ИИС в текущих условиях ставки ЦБ, и что туда класть — "
            "облигации или акции? Дай рамку рассуждения, не финсовет."
        ),
    },
]


def build_llm(args) -> object:
    """Return a live LLM client.

    Default: SubprocessLLM if --llm-cmd is given, else a stub that REFUSES to run
    so nobody accidentally 'measures efficacy' against a fake model.
    """
    if args.llm_cmd:
        return SubprocessLLM(args.llm_cmd, timeout_seconds=args.timeout)

    # ---- Option B: paste your API call here and return FunctionLLM(call) ----
    # def call(prompt: str) -> str:
    #     ...your real model...
    #     return text
    # return FunctionLLM(call)

    raise SystemExit(
        "No real model configured. Pass --llm-cmd ... for a CLI model, or edit "
        "build_llm() to wire your API. Refusing to run against a stub — a fake "
        "model produces a fake efficacy number."
    )


def run_pairs(tasks: List[dict], llm, strength: str, seed: int) -> tuple[list, dict]:
    """Run each task; return (blind_rows, answer_key)."""
    rng = random.Random(seed)
    blind_rows = []
    key = {}
    for t in tasks:
        proxy = CogProxyV33(llm=llm, config=CogProxyConfig(forced_strength=strength))
        result = proxy.run(t["prompt"])
        baseline = result.baseline_answer.strip()
        final = result.final_answer.strip()

        # If the pipeline fell back, final == baseline. Record that explicitly:
        # it's a forced tie and tells you the amplifier declined to act.
        pipeline_acted = (final != baseline)

        # Shuffle which slot the pipeline output lands in, so the judge is blind.
        if rng.random() < 0.5:
            a, b, pipeline_slot = baseline, final, "B"
        else:
            a, b, pipeline_slot = final, baseline, "A"

        blind_rows.append({
            "task_id": t["id"],
            "prompt": t["prompt"],
            "option_A": a,
            "option_B": b,
        })
        key[t["id"]] = {
            "pipeline_slot": pipeline_slot,
            "pipeline_acted": pipeline_acted,
            "path": result.path,
            "selected_answer_name": result.selected_answer_name,
        }
    return blind_rows, key


def cmd_generate(args):
    llm = build_llm(args)
    tasks = DEFAULT_TASKS
    if args.tasks:
        tasks = [json.loads(l) for l in Path(args.tasks).read_text(encoding="utf-8").splitlines() if l.strip()]

    blind_rows, key = run_pairs(tasks, llm, args.strength, args.seed)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    blind_path = out_dir / "ab_pairs_blind.jsonl"
    key_path = out_dir / "ab_answer_key.json"

    with blind_path.open("w", encoding="utf-8") as f:
        for row in blind_rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    key_path.write_text(json.dumps(key, ensure_ascii=False, indent=2), encoding="utf-8")

    acted = sum(1 for v in key.values() if v["pipeline_acted"])
    print(json.dumps({
        "blind_pairs": str(blind_path),
        "answer_key": str(key_path),
        "tasks": len(blind_rows),
        "pipeline_acted_on": acted,
        "forced_ties_fallback": len(blind_rows) - acted,
        "next": "Have a human or judge MODEL pick the better answer per task (A/B/tie), "
                "save rows {'task_id','winner'} to graded.jsonl, then run --grade graded.jsonl",
    }, ensure_ascii=False, indent=2))


def cmd_grade(args):
    key = json.loads(Path(args.key).read_text(encoding="utf-8"))
    graded = [json.loads(l) for l in Path(args.grade).read_text(encoding="utf-8").splitlines() if l.strip()]

    win = loss = tie = unknown = 0
    forced_tie_but_judged_diff = 0
    details = []
    for g in graded:
        tid = g["task_id"]
        winner = g["winner"].strip().upper()
        if tid not in key:
            unknown += 1
            continue
        meta = key[tid]
        slot = meta["pipeline_slot"]
        if winner == "TIE":
            tie += 1
            verdict = "tie"
        elif winner == slot:
            win += 1
            verdict = "win"
        elif winner in ("A", "B"):
            loss += 1
            verdict = "loss"
        else:
            unknown += 1
            verdict = "unknown"
        if not meta["pipeline_acted"] and verdict != "tie":
            # pipeline returned baseline verbatim, yet judge saw a difference -> grading noise
            forced_tie_but_judged_diff += 1
        details.append({"task_id": tid, "verdict": verdict, "pipeline_acted": meta["pipeline_acted"]})

    n = win + loss + tie
    print(json.dumps({
        "n_graded": n,
        "wins": win,
        "ties": tie,
        "losses": loss,
        "unknown_rows": unknown,
        "win_rate": round(win / n, 3) if n else None,
        "loss_rate": round(loss / n, 3) if n else None,
        "net_value_rate": round((win - loss) / n, 3) if n else None,
        "sanity_forced_tie_but_judged_different": forced_tie_but_judged_diff,
        "interpretation": {
            "win_rate": "share of tasks where pipeline beat raw baseline = real efficacy",
            "loss_rate": "should be ~0; nonzero means the no-regression guarantee leaks in practice",
            "ties": "pipeline spent tokens and changed nothing a judge cares about",
        },
        "per_task": details,
    }, ensure_ascii=False, indent=2))


def main(argv=None):
    p = argparse.ArgumentParser(description="Blind A/B efficacy harness for CogProxy")
    sub = p.add_subparsers(dest="mode", required=True)

    g = sub.add_parser("generate", help="Run model + pipeline, emit blind pairs + key")
    g.add_argument("--llm-cmd", nargs="+", help="CLI model; prompt to stdin, answer from stdout")
    g.add_argument("--strength", choices=["weak", "hybrid", "strong"], default="strong")
    g.add_argument("--tasks", help="Optional JSONL of {'id','prompt'} to override defaults")
    g.add_argument("--out-dir", default="ab_out")
    g.add_argument("--seed", type=int, default=7)
    g.add_argument("--timeout", type=int, default=120)
    g.set_defaults(func=cmd_generate)

    gr = sub.add_parser("grade", help="Join human/judge verdicts against the key -> real win rate")
    gr.add_argument("--grade", required=True, help="JSONL of {'task_id','winner': 'A'|'B'|'tie'}")
    gr.add_argument("--key", default="ab_out/ab_answer_key.json")
    gr.set_defaults(func=cmd_grade)

    args = p.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
