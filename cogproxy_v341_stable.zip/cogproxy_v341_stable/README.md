# CogProxy v3.3.6 — no task router

Эта версия убирает опасный task router / domain classifier. Система больше не решает по ключевым словам, что задача является `architecture_case`, `career_advice`, `recommendation`, `llm_quality` и т.д.

Почему удалено:

- `продукты` раньше могло ошибочно матчиться как `ук`;
- `ответы студента` могло ошибочно тянуться в LLM-quality;
- A/B-test, postmortem, product strategy и другие задачи могли попадать не в тот доменный контракт;
- из-за этого scorer мог поощрять не реальное решение, а совпадение с не тем шаблоном.

## Новый принцип

```text
user_input
 ↓
neutral_task_profile       # без доменной классификации
 ↓
universal_answer_contract  # один общий контракт качества
 ↓
baseline_answer
 ↓
weak / hybrid / strong amplification mode
 ↓
critique / graph-state / challenger
 ↓
compare with baseline
 ↓
если improved лучше и не потерял задачу → improved
иначе → baseline
```

## Что осталось

Остался не task router, а выбор режима усиления по силе модели:

- `weak` — жёсткий graph-state и заполнение малых полей;
- `hybrid` — structured path + expert critique;
- `strong` — baseline, critique, alternative angles, challenger, compare.

Это не классифицирует задачу по домену. Это только выбирает, насколько жёстко вести модель.

## Что проверяется

```bash
python -m pytest -q
```

Текущий результат:

```text
13 passed
```

## Ключевые файлы

```text
cogproxy_v33/task_profile.py   # neutral profile, no domain classification
cogproxy_v33/contract.py       # universal answer contract
cogproxy_v33/orchestrator.py   # baseline → amplification → compare → fallback
cogproxy_v33/weak_path.py      # graph-state for weak model
cogproxy_v33/strong_path.py    # expert amplification for strong model
cogproxy_v33/gates.py          # anti-bloat and baseline comparison
cogproxy_v33/scoring.py        # universal scoring and grounding guardrails
```

## Главная гарантия

Усилитель не имеет права выпускать ответ хуже baseline. Если candidate теряет задачу, загрязняет ответ чужим шаблоном или не даёт достаточной дельты, возвращается baseline.

---

## v3.4.1 — стабилизация (исправление gate)

### Что было сломано

В режиме LLM-судьи (`use_llm_judge=True`) финальный `quality_gate` перепроверял
уже одобренный судьёй ответ лексическим счётчиком с абсолютным порогом 0.82.
Счётчик считает попадания в доменный словарь (банк/архитектура), поэтому на
любых других темах (физика, кулинария, спорт, право и т.д.) он ставит низкую
оценку даже отличному ответу. Из-за этого КАЖДОЕ одобренное судьёй улучшение
помечалось как `improved_soft_fail` и выпускалось только через аварийный путь.

Масштабный тест на 42 нефинансовых кейсах: чистый релиз `improved` — **0/32**.

### Что исправлено

Когда acceptance-решение принимает судья, лексический порог больше НЕ применяется.
Гарантию «не хуже baseline» обеспечивает сам судья (улучшение принимается только
если победило в обоих порядках при position-swap). Сохранён лёгкий структурный
guardrail на уход от темы (grounding/contamination), без числового порога.

Старый путь без судьи (`use_llm_judge=False`) намеренно не тронут: он завязан на
банковский словарь, где порог 0.82 корректен, и его пинят существующие тесты.

После исправления на тех же 42 кейсах: чистый релиз `improved` — **32/32**,
аварийных `improved_soft_fail` — 0. Штатные тесты: 22/22.

### Рекомендованный режим

Для любых задач вне банк/архитектуры используйте готовый конфиг:

```python
from cogproxy_v33.orchestrator import CogProxyConfig, CogProxyV33

cfg = CogProxyConfig.recommended(model_name="your-model")
proxy = CogProxyV33(llm=your_llm, config=cfg)
result = proxy.run(user_input)
```

### Масштабный тест

```bash
python run_hard_cases.py
```

42 кейса (32 реальных улучшения, 5 контрольных, 5 adversarial-вода) с агрегированной
статистикой и разбивкой по категориям. Реестр кейсов — `case_registry.py`.

### Ограничение теста (честно)

Судья в тестовом харнесе знает правильный ответ заранее (через `judge_pref`),
поэтому проверена КОРРЕКТНОСТЬ АРХИТЕКТУРЫ acceptance, а не устойчивость живой
модели-судьи к красивой пустышке. Последнее проверяется только реальным вторым
вызовом модели.
