import importlib.util, sys, traceback, pathlib

sys.path.insert(0, str(pathlib.Path(__file__).parent))
test_dir = pathlib.Path(__file__).parent / "tests"
passed = failed = 0
failures = []

for tf in sorted(test_dir.glob("test_*.py")):
    spec = importlib.util.spec_from_file_location(tf.stem, tf)
    mod = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(mod)
    except Exception as e:
        failures.append((tf.name + " [import]", traceback.format_exc()))
        failed += 1
        continue
    for name in dir(mod):
        if name.startswith("test_"):
            fn = getattr(mod, name)
            if callable(fn):
                try:
                    fn()
                    passed += 1
                    print(f"PASS {tf.name}::{name}")
                except Exception:
                    failed += 1
                    failures.append((f"{tf.name}::{name}", traceback.format_exc()))
                    print(f"FAIL {tf.name}::{name}")

print(f"\n=== {passed} passed, {failed} failed ===")
for n, tb in failures:
    print(f"\n----- {n} -----\n{tb}")
sys.exit(1 if failed else 0)
