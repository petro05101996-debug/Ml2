from cogproxy_v33.model_probe import choose_path, probe_model_capability


def test_choose_model_mode_thresholds():
    assert choose_path(0.64) == "weak"
    assert choose_path(0.65) == "hybrid"
    assert choose_path(0.84) == "hybrid"
    assert choose_path(0.85) == "strong"


def test_forced_strength_uses_strong_mode():
    profile = probe_model_capability("x", "baseline", forced_strength="strong")
    assert profile.path == "strong"
    assert profile.capability_score == 0.9
