from cogproxy_v33.llm import FunctionLLM
from cogproxy_v33.orchestrator import CogProxyConfig, CogProxyV33


class StrongDemo(FunctionLLM):
    def __init__(self):
        super().__init__(self._gen)

    def _gen(self, prompt: str) -> str:
        lower = prompt.lower()
        if "baseline" in lower or "первичный" in lower:
            return "Нужно улучшать ответы через проверки качества. Для слабой модели нужна структура, для сильной критика."
        if "критик" in lower or "critique" in lower:
            return "Не хватает baseline comparison, explicit fallback, anti-bloat, quality gate и regression tests."
        if "угол" in lower or "angle" in lower:
            return "Добавь orthogonal alternatives, challenger answer, comparative judge и defect classification."
        return "Собери adaptive classifier, baseline comparison, quality gate, anti-bloat и fallback."


class BadImprover(FunctionLLM):
    def __init__(self):
        super().__init__(self._gen)

    def _gen(self, prompt: str) -> str:
        lower = prompt.lower()
        if "baseline" in lower or "первичный" in lower:
            return "Добавь baseline comparison, quality gate, anti-bloat, defect classification, практический порядок внедрения и проверку на регрессию для слабой и сильной модели."
        return "Всё нормально."


def test_strong_path_improves_baseline():
    proxy = CogProxyV33(llm=StrongDemo(), config=CogProxyConfig(forced_strength="strong"))
    result = proxy.run("Нужно чтобы сильная модель тоже улучшала ответы в CogProxy")
    assert result.path == "strong"
    assert result.final_score.final_score > result.baseline_score.final_score
    assert result.improved is True
    assert "baseline" in result.final_answer.lower()
    assert "anti-bloat" in result.final_answer.lower()


def test_pipeline_falls_back_when_delta_below_release_threshold():
    proxy = CogProxyV33(
        llm=BadImprover(),
        config=CogProxyConfig(forced_strength="strong", min_improvement_delta=0.9),
    )
    result = proxy.run("Нужно чтобы сильная модель тоже улучшала ответы")
    assert result.selected_answer_name == "baseline"
    assert result.final_answer == result.baseline_answer
    assert result.final_score.final_score == result.baseline_score.final_score


def test_weak_path_uses_structured_graph():
    proxy = CogProxyV33(llm=StrongDemo(), config=CogProxyConfig(forced_strength="weak"))
    result = proxy.run("Нужно повысить качество ответов слабой модели")
    stages = [t.stage for t in result.traces]
    assert "context_capture" in stages
    assert "structure" in stages
    assert "validation" in stages
    assert result.path == "weak"
