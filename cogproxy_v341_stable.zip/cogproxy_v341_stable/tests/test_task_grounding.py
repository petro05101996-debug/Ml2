from cogproxy_v33 import CogProxyConfig, CogProxyV33
from cogproxy_v33.llm import FunctionLLM


class GoodCarBaselineLLM(FunctionLLM):
    def __init__(self):
        super().__init__(self._gen)

    def _gen(self, prompt: str) -> str:
        lower = prompt.lower()
        if "baseline" in lower or "первичный" in lower:
            return (
                "Для бюджета 500 000 рублей критерии выбора: живой атмосферный мотор, "
                "простая коробка, доступные запчасти и минимум коррозии. Варианты: "
                "Renault Logan/Sandero 1.6, Hyundai Solaris/Kia Rio 1.4/1.6, Nissan Almera G15. "
                "Риски: такси, скрученный пробег, ржавчина, перегрев. Проверка отзывов: Logan дешевле "
                "в содержании, Solaris/Rio ликвиднее. Итоговый выбор: первым смотреть Renault Logan/Sandero 1.6."
            )
        return "Можно выбрать разные варианты, но надо проверять."


def test_non_llm_task_does_not_get_overwritten_by_cogproxy_template():
    proxy = CogProxyV33(llm=GoodCarBaselineLLM(), config=CogProxyConfig(forced_strength="strong"))
    result = proxy.run("Найди вариант надежной машины в РФ с бюджетом 500000")
    assert result.selected_answer_name == "baseline"
    assert "Renault Logan" in result.final_answer
    assert "CogProxy" not in result.final_answer


def test_non_llm_challenger_is_direct_not_cogproxy_template():
    proxy = CogProxyV33(llm=GoodCarBaselineLLM(), config=CogProxyConfig(forced_strength="strong"))
    result = proxy.run("Найди вариант надежной машины в РФ с бюджетом 500000")
    challenger = next(c for c in result.candidates if c.name == "challenger")
    assert "CogProxy" not in challenger.answer
