from cogproxy_v33.task_profile import detect_task_profile
from cogproxy_v33.gates import compare_answers
from cogproxy_v33.contract import build_answer_contract


def test_no_task_classifier_all_domains_use_universal_profile():
    examples = [
        "Составь короткий список продуктов на ужин: паста с курицей и салатом",
        "Спроектируй платформу онлайн-экзамена: автосохранение ответов студента",
        "Банк и УК обмениваются статусами через Kafka, нужны outbox inbox, порядок, DLQ и сверка",
        "Проверь договор внедрения CRM и риски для заказчика",
    ]
    for text in examples:
        task = detect_task_profile(text)
        assert task.task_type == "universal_task"
        assert task.domain == "universal"


def test_strong_baseline_not_replaced_by_shorter_template():
    user_input = "Проверь идею: для сильной LLM нужен baseline comparison, критика, альтернативные углы и fallback."
    task = detect_task_profile(user_input)
    contract = build_answer_contract(task)
    baseline = """
Да, идея правильная. Для сильной модели жёсткий граф может ухудшить ответ, потому что отнимает свободу рассуждения. Усилитель должен сначала получить baseline, затем построить answer_contract, провести expert_critique, сгенерировать несколько ортогональных углов, собрать challenger answer и сравнить его с baseline. Quality gate должен выпускать только версию с положительной дельтой, а anti-bloat gate обязан удалить текст, который делает ответ длиннее, но не полезнее. Если improved не лучше baseline или теряет grounding, нужен fallback к baseline. Для слабой модели, наоборот, нужен scaffold: малые поля, строгая структура, defect return и repair loop. Поэтому универсальный CogProxy должен выбирать режим усиления по силе модели, а не классифицировать домен задачи.
"""
    shorter = "Да. Нужно использовать baseline, answer_contract, expert_critique, alternative angles, challenger answer, quality gate, anti-bloat и fallback к baseline. Слабой модели нужна структура, сильной модели нужна критика."
    comparison, _, _ = compare_answers(task, contract, baseline, shorter)
    assert not comparison.improved_is_better
