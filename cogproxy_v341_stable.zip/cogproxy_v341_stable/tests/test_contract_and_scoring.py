from cogproxy_v33.contract import build_answer_contract
from cogproxy_v33.scoring import score_answer
from cogproxy_v33.task_profile import detect_task_profile


def test_contract_is_universal_not_domain_classified():
    task = detect_task_profile("Нужно чтобы сильная и слабая LLM улучшали ответы через граф")
    contract = build_answer_contract(task)
    assert task.task_type == "universal_task"
    assert "прямой ответ" in contract.must_have
    assert "критерии качества" in contract.must_have
    assert "практические шаги" in contract.must_have
    assert "baseline comparison" not in contract.must_have
    assert "статусная модель" not in contract.must_have


def test_scoring_detects_missing_universal_contract_items():
    task = detect_task_profile("Нужно улучшить качество ответов LLM")
    contract = build_answer_contract(task)
    score = score_answer(task, contract, "Нужно просто добавить проверки качества.")
    assert score.final_score < 0.7
    assert score.missing
