from cogproxy_v33.orchestrator import CogProxyConfig, CogProxyV33
from cogproxy_v33.llm import FunctionLLM
from cogproxy_v33.judge import judge_pair, _parse_pick
from cogproxy_v33.improver import improve_answer
from cogproxy_v33.task_profile import detect_task_profile
from cogproxy_v33.contract import build_answer_contract


CASE = "Оцени обратный поток статусов банк-УК через kafka: порядок, идемпотентность, сверка, DLQ."
THIN = "Сделать через kafka, сохранять статусы, нужны retry и DLQ."
RICH = ("Инвариант: банк не финализирует по устаревшему событию. State machine SENT_TO_UK→UK_SUCCESS. "
        "Идемпотентность: inbox по eventId, outbox. Порядок: ключ партиционирования operationId. "
        "reconciliation сверка, DLQ с reasonCode, trade-off, проверка по метрикам lag.")


def _richness(t: str) -> int:
    keys = ["state machine", "partition", "operationid", "inbox", "outbox",
            "reconciliation", "сверка", "dlq", "идемпотент", "инвариант", "партиционир"]
    return sum(k in t.lower() for k in keys)


def _honest_judge_reply(prompt: str) -> str:
    a = prompt.split("ОТВЕТ 1:")[-1].split("ОТВЕТ 2:")[0]
    b = prompt.split("ОТВЕТ 2:")[-1].split("Твой вердикт")[0]
    ra, rb = _richness(a), _richness(b)
    if ra > rb + 1:
        return "1"
    if rb > ra + 1:
        return "2"
    return "tie"


# ---------- parse ----------
def test_parse_pick_handles_variants():
    assert _parse_pick("1") == "1"
    assert _parse_pick("2\nпотому что конкретнее") == "2"
    assert _parse_pick("tie") == "tie"
    assert _parse_pick("ничья, разницы нет") == "tie"
    assert _parse_pick("") == "tie"
    assert _parse_pick("Ответ 2 лучше") == "2"


# ---------- improver ----------
def test_improver_targets_missing_and_changes_answer():
    task = detect_task_profile(CASE)
    c = build_answer_contract(task)
    improved, targeted = improve_answer(task, c, THIN, FunctionLLM(lambda p: RICH))
    assert targeted, "should identify unmet contract aspects on a thin answer"
    assert improved.strip() == RICH.strip()


def test_improver_keeps_answer_when_model_returns_trivial():
    task = detect_task_profile(CASE)
    c = build_answer_contract(task)
    # model returns near-empty improvement -> keep original
    improved, _ = improve_answer(task, c, RICH, FunctionLLM(lambda p: "ок"))
    assert improved.strip() == RICH.strip()


# ---------- judge double-run ----------
def test_judge_accepts_only_on_double_win():
    task = detect_task_profile(CASE)
    v = judge_pair(task, THIN, RICH, FunctionLLM(_honest_judge_reply))
    assert v.improved_is_better is True
    assert v.order1_pick == "improved" and v.order2_pick == "improved"


def test_judge_no_change_short_circuits_to_tie():
    task = detect_task_profile(CASE)
    v = judge_pair(task, RICH, RICH, FunctionLLM(_honest_judge_reply))
    assert v.improved_is_better is False
    assert v.winner == "tie"


def test_judge_position_bias_yields_tie_not_false_win():
    task = detect_task_profile(CASE)
    # Always picks slot 1 — pure position bias. Must NOT yield a win.
    v = judge_pair(task, THIN, RICH, FunctionLLM(lambda p: "1"))
    assert v.improved_is_better is False
    assert v.winner == "tie"


# ---------- end-to-end through orchestrator ----------
def _good_model(prompt: str) -> str:
    p = prompt.lower()
    if "твой вердикт" in p:
        return _honest_judge_reply(prompt)
    if "улучшенный ответ" in p or ("дополни" in p and "аспект" in p):
        return RICH
    return THIN


def _padder_model(prompt: str) -> str:
    p = prompt.lower()
    if "твой вердикт" in p:
        return _honest_judge_reply(prompt)
    if "улучшенный ответ" in p or ("дополни" in p and "аспект" in p):
        return THIN + " Это важная задача, требующая внимания и системного подхода. Следует учитывать нюансы."
    return THIN


def test_pipeline_accepts_real_improvement():
    cfg = CogProxyConfig(forced_strength="strong", use_directed_improver=True, use_llm_judge=True)
    r = CogProxyV33(llm=FunctionLLM(_good_model), config=cfg).run(CASE)
    assert r.improved is True
    assert _richness(r.final_answer) > _richness(r.baseline_answer)


def test_pipeline_rejects_padding_keeps_baseline():
    cfg = CogProxyConfig(forced_strength="strong", use_directed_improver=True, use_llm_judge=True)
    r = CogProxyV33(llm=FunctionLLM(_padder_model), config=cfg).run(CASE)
    assert r.improved is False
    assert r.final_answer.strip() == r.baseline_answer.strip()


def test_no_regression_guarantee_under_new_path():
    # Across both model behaviors, final must never score below baseline.
    from cogproxy_v33.scoring import score_answer
    cfg = CogProxyConfig(forced_strength="strong", use_directed_improver=True, use_llm_judge=True)
    for fn in (_good_model, _padder_model):
        r = CogProxyV33(llm=FunctionLLM(fn), config=cfg).run(CASE)
        assert r.final_score.final_score >= r.baseline_score.final_score - 1e-9
