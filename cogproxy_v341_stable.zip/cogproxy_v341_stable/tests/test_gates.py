from cogproxy_v33.contract import build_answer_contract
from cogproxy_v33.gates import anti_bloat_gate, compare_answers
from cogproxy_v33.task_profile import detect_task_profile


def test_anti_bloat_removes_duplicate_lines():
    text = "A\nA\n\nB\nB\n"
    assert anti_bloat_gate(text) == "A\n\nB"


def test_compare_rejects_worse_answer():
    task = detect_task_profile("Как сделать CogProxy чтобы сильная модель улучшалась")
    contract = build_answer_contract(task)
    baseline = "Добавь baseline comparison, quality gate, anti-bloat, defect classification и проверку на регрессию. Сделай практические шаги."
    worse = "Надо подумать глубже."
    comparison, baseline_score, worse_score = compare_answers(task, contract, baseline, worse)
    assert not comparison.improved_is_better
    assert worse_score.final_score < baseline_score.final_score
